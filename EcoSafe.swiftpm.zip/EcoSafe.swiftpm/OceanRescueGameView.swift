import SwiftUI

struct OceanRescueGameView: View {
    @EnvironmentObject var appState: AppState
    @Environment(\.dismiss) private var dismiss
    @StateObject private var engine = GameEngine()
    
    @State private var shakeOffset:    CGFloat = 0
    @State private var didRegisterGame = false
    @State private var screenFlash     = false
    @State private var showSavedPopup  = false
    @State private var savedGrams:     Double  = 0
    @State private var popupScale:     CGFloat = 0.5
    @State private var ringPulse:      CGFloat = 1.0
    @State private var particleActive  = false
    
    var body: some View {
        GeometryReader { geo in
            TimelineView(.animation(paused: engine.phase == .idle || engine.phase == .summary)) { ctx in
                ZStack {
                    gameBackground
                    
                    if screenFlash {
                        Color.white.opacity(0.08).ignoresSafeArea().allowsHitTesting(false)
                    }
                    
                    BubbleBackground()
                    
                    let health = appState.oceanHealth
                    if health > 0.2 { SwimmingFish(yFraction: 0.38, delay: 2,  speed: 15, size: 15, emoji: "🐟") }
                    if health > 0.5 { SwimmingFish(yFraction: 0.62, delay: 7,  speed: 11, size: 12, emoji: "🐠") }
                    if health > 0.8 { SwimmingFish(yFraction: 0.28, delay: 12, speed: 18, size: 19, emoji: "🐡") }
                    
                    switch engine.phase {
                    case .idle, .countdown:
                        GameReadyScreen(
                            round:     engine.activeRound + 1,
                            total:     engine.totalRounds,
                            type:      engine.currentType,
                            countdown: engine.countdownValue
                        )
                    case .playing:
                        gamePlayLayer(size: geo.size)
                    case .result:
                        GameResultCard(success: engine.resultIsSuccess, type: engine.currentType)
                    case .summary:
                        GameSummaryView(engine: engine) {
                            // Show plastic-saved popup if any items were caught
                            if savedGrams > 0 {
                                withAnimation(.spring(response: 0.45, dampingFraction: 0.6)) {
                                    showSavedPopup = true
                                    popupScale     = 1.0
                                }
                                withAnimation(.easeInOut(duration: 1.4).repeatForever(autoreverses: true).delay(0.3)) {
                                    ringPulse = 1.15
                                }
                                DispatchQueue.main.asyncAfter(deadline: .now() + 0.2) {
                                    particleActive = true
                                }
                            } else {
                                dismiss()
                            }
                        } onReplay: { engine.restart() }
                    }
                    
                    ForEach(engine.scorePopups) { pop in
                        Text(pop.text)
                            .font(.system(size: 16, weight: .heavy, design: .rounded))
                            .foregroundColor(pop.color)
                            .shadow(color: pop.color.opacity(0.5), radius: 4)
                            .position(CGPoint(x: pop.position.x, y: pop.position.y + pop.yOffset))
                            .opacity(pop.opacity)
                            .allowsHitTesting(false)
                    }
                    
                    if engine.showSplash {
                        SplashEffect(color: engine.splashColor)
                            .position(engine.splashPos).allowsHitTesting(false)
                    }
                    
                    // ── Plastic Saved Popup ───────────────────────
                    if showSavedPopup {
                        PlasticSavedPopup(
                            grams:         savedGrams,
                            caughtCount:   engine.caughtCount,
                            popupScale:    popupScale,
                            ringPulse:     ringPulse,
                            particleActive: particleActive,
                            onDismiss: {
                                withAnimation(.easeIn(duration: 0.25)) { showSavedPopup = false }
                                dismiss()
                            }
                        )
                    }
                }
                .offset(x: shakeOffset)
                .onChange(of: ctx.date) { _, date in
                    let prevLives = engine.lives
                    engine.tick(date: date, size: geo.size)
                    if engine.lives < prevLives { triggerShake(); flashScreen() }
                }
            }
        }
        .ignoresSafeArea()
        .onAppear { engine.startGame(); didRegisterGame = false }
        .onChange(of: engine.phase) { _, phase in
            if phase == .summary && !didRegisterGame {
                didRegisterGame = true
                appState.gamesPlayed += 1
                if engine.isPerfect { appState.perfectGames += 1 }
                appState.improveOceanHealth(by: Double(engine.caughtCount) * EcoConfiguration.healthGainPerCatch)
                appState.damageOceanHealth(by: Double(engine.missedCount) * EcoConfiguration.healthLossPerMiss)
                // Credit plastic to daily ring + totals for each caught item
                let gramsEarned = Double(engine.caughtCount) * EcoConfiguration.gramsPerScan
                if gramsEarned > 0 {
                    appState.totalPlastic      += gramsEarned
                    appState.dailyGoalProgress += gramsEarned
                    appState.totalScansCount   += engine.caughtCount
                    savedGrams = gramsEarned
                }
                appState.checkAchievements()
            }
        }
        .accessibilityLabel("Ocean Rescue Game")
    }
    
    var gameBackground: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.04, green: 0.10, blue: 0.26),
                         Color(red: 0.04, green: 0.22, blue: 0.44),
                         Color(red: 0.00, green: 0.40, blue: 0.54)],
                startPoint: .top, endPoint: .bottom
            ).ignoresSafeArea()
            GameWavesBG()
        }
    }
    
    @ViewBuilder
    func gamePlayLayer(size: CGSize) -> some View {
        ZStack {
            VStack { GameHUDView(engine: engine).padding(.top, 52); Spacer() }
            VStack {
                Spacer().frame(height: 130)
                Label("Slide the bin to catch the \(engine.currentType.label)",
                      systemImage: "hand.draw.fill")
                .font(.system(size: 12, weight: .semibold))
                .foregroundColor(.white.opacity(0.55))
                .accessibilityHidden(true)
                Spacer()
            }
            GameTrashView(type: engine.currentType)
                .position(x: engine.trashX, y: engine.trashY)
                .accessibilityLabel("Falling \(engine.currentType.label)")
            
            ForEach(Array(engine.binTrail.enumerated()), id: \.offset) { idx, tx in
                Image(systemName: "trash.fill").font(.system(size: 20))
                    .foregroundColor(engine.currentType.color
                        .opacity(Double(idx) / Double(engine.binTrail.count) * 0.28))
                    .position(x: tx, y: size.height - 80)
                    .allowsHitTesting(false)
            }
            
            GameBinView(type: engine.currentType, isDragging: engine.isDragging)
                .position(x: engine.binX, y: size.height - 80)
                .accessibilityLabel("Recycling bin. Slide to catch \(engine.currentType.label).")
                .gesture(DragGesture(minimumDistance: 0)
                    .onChanged { val in engine.isDragging = true; engine.moveBin(to: val.location.x) }
                    .onEnded   { _ in engine.endDrag() }
                )
        }
    }
    
    private func flashScreen() {
        withAnimation(.easeIn(duration: 0.08)) { screenFlash = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.12) {
            withAnimation(.easeOut(duration: 0.18)) { screenFlash = false }
        }
    }
    
    private func triggerShake() {
        let steps: [(Double, CGFloat)] = [(0,12),(0.06,-12),(0.12,8),(0.18,-5),(0.25,0)]
        for (delay, val) in steps {
            DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                withAnimation(.default) { shakeOffset = val }
            }
        }
    }
}

struct SplashEffect: View {
    let color: Color
    @State private var active = false
    var body: some View {
        ZStack {
            ForEach(0..<12) { i in
                Circle().fill(color.opacity(0.7))
                    .frame(width: CGFloat.random(in: 5...11), height: CGFloat.random(in: 5...11))
                    .offset(
                        x: active ? cos(Double(i)/12 * .pi*2) * CGFloat.random(in: 22...50) : 0,
                        y: active ? sin(Double(i)/12 * .pi*2) * CGFloat.random(in: 22...50) : 0
                    )
                    .opacity(active ? 0 : 0.9)
            }
        }
        .onAppear { withAnimation(.easeOut(duration: 0.55)) { active = true } }
    }
}

struct GameTrashView: View {
    let type: TrashType
    @State private var wobble    = false
    @State private var glowScale: CGFloat = 1.0
    var body: some View {
        VStack(spacing: 3) {
            ZStack {
                Circle().fill(type.color.opacity(0.16)).frame(width: 64, height: 64).scaleEffect(glowScale)
                Image(systemName: type.icon)
                    .font(.system(size: 26, weight: .bold)).foregroundColor(type.color)
                    .rotationEffect(.degrees(wobble ? 10 : -10))
            }
            .shadow(color: type.color.opacity(0.5), radius: 8)
            Text(type.label)
                .font(.system(size: 10, weight: .bold)).foregroundColor(.white.opacity(0.9))
                .padding(.horizontal, 7).padding(.vertical, 2)
                .background(type.color.opacity(0.3)).cornerRadius(5)
        }
        .onAppear {
            withAnimation(.easeInOut(duration: 0.6).repeatForever(autoreverses: true)) { wobble = true }
            withAnimation(.easeInOut(duration: 1.1).repeatForever(autoreverses: true)) { glowScale = 1.18 }
        }
    }
}
struct GameBinView: View {
    let type: TrashType; let isDragging: Bool
    var body: some View {
        VStack(spacing: 4) {
            ZStack {
                if isDragging {
                    Circle().fill(type.color.opacity(0.22)).frame(width: 88, height: 88).blur(radius: 8)
                }
                RoundedRectangle(cornerRadius: 16)
                    .fill(type.color.opacity(isDragging ? 0.28 : 0.14))
                    .frame(width: 76, height: 66)
                    .overlay(RoundedRectangle(cornerRadius: 16)
                        .stroke(type.color.opacity(isDragging ? 0.9 : 0.45),
                                lineWidth: isDragging ? 2.5 : 1.5))
                    .shadow(color: type.color.opacity(isDragging ? 0.55 : 0.18),
                            radius: isDragging ? 14 : 5)
                    .scaleEffect(isDragging ? 1.08 : 1.0)
                    .animation(.spring(response: 0.22, dampingFraction: 0.55), value: isDragging)
                VStack(spacing: 3) {
                    Image(systemName: "trash.fill").font(.system(size: 24, weight: .bold)).foregroundColor(type.color)
                    Image(systemName: "arrow.left.and.right").font(.system(size: 9)).foregroundColor(type.color.opacity(0.55))
                }
            }
            Text(type.label).font(.system(size: 11, weight: .semibold)).foregroundColor(.white.opacity(0.82))
        }
    }
}

struct GameHUDView: View {
    @ObservedObject var engine: GameEngine
    var body: some View {
        VStack(spacing: 6) {
            HStack(alignment: .center) {
                HStack(spacing: 4) {
                    ForEach(0..<3) { i in
                        Image(systemName: i < engine.lives ? "heart.fill" : "heart")
                            .foregroundColor(i < engine.lives ? .red : .white.opacity(0.2))
                            .font(.system(size: 13))
                            .scaleEffect(i == engine.lives && engine.lives < 3 ? 1.3 : 1.0)
                            .animation(.spring(response: 0.3, dampingFraction: 0.5), value: engine.lives)
                    }
                }
                .accessibilityLabel("\(engine.lives) lives remaining")
                Spacer()
                HStack(spacing: 5) {
                    Image(systemName: engine.currentType.icon).font(.system(size: 10, weight: .bold))
                        .foregroundColor(engine.currentType.color)
                    Text("R\(engine.activeRound+1)/\(engine.totalRounds)")
                        .font(.system(size: 11, weight: .bold)).foregroundColor(.white)
                    Text("·").foregroundColor(.white.opacity(0.4))
                    Text(engine.currentType.label).font(.system(size: 11, weight: .semibold))
                        .foregroundColor(engine.currentType.color)
                }
                .padding(.horizontal, 9).padding(.vertical, 5)
                .background(engine.currentType.color.opacity(0.16)).cornerRadius(9)
                .overlay(RoundedRectangle(cornerRadius: 9)
                    .stroke(engine.currentType.color.opacity(0.38), lineWidth: 1))
                Spacer()
                VStack(alignment: .trailing, spacing: 1) {
                    Text("\(engine.score)")
                        .font(.system(size: 18, weight: .heavy, design: .rounded)).foregroundColor(.white)
                        .contentTransition(.numericText()).animation(.spring(), value: engine.score)
                    if engine.combo > 1 {
                        Text("×\(engine.combo) combo")
                            .font(.system(size: 9, weight: .bold)).foregroundColor(OceanTheme.gold)
                            .transition(.scale.combined(with: .opacity))
                    }
                }
                .accessibilityLabel("Score \(engine.score)")
            }
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 3).fill(Color.white.opacity(0.08)).frame(height: 5)
                    RoundedRectangle(cornerRadius: 3).fill(timerColor)
                        .frame(width: max(0, g.size.width * CGFloat(engine.gameTimeRemaining / engine.gameTimeLimit)), height: 5)
                        .animation(.linear(duration: 0.1), value: engine.gameTimeRemaining)
                }
            }.frame(height: 5)
                .accessibilityLabel("Time remaining: \(Int(engine.gameTimeRemaining)) seconds")
        }
        .padding(.horizontal, 14).padding(.vertical, 10)
        .background(.ultraThinMaterial.opacity(0.6)).cornerRadius(14)
        .padding(.horizontal, 14)
    }
    var timerColor: Color {
        let r = engine.gameTimeRemaining / engine.gameTimeLimit
        return r > 0.5 ? OceanTheme.teal : r > 0.25 ? OceanTheme.gold : OceanTheme.coral
    }
}

struct GameReadyScreen: View {
    let round: Int; let total: Int; let type: TrashType; let countdown: Int
    @State private var countScale: CGFloat = 0.5
    @State private var iconPulse:  CGFloat = 1.0
    var body: some View {
        ZStack {
            Color.black.opacity(0.52).ignoresSafeArea()
            VStack(spacing: 18) {
                Text("Round \(round) of \(total)")
                    .font(.system(size: 14, weight: .semibold)).foregroundColor(.white.opacity(0.6))
                    .padding(.horizontal, 14).padding(.vertical, 5)
                    .background(Color.white.opacity(0.10)).cornerRadius(10)
                VStack(spacing: 10) {
                    ZStack {
                        Circle().fill(type.color.opacity(0.18)).frame(width: 84, height: 84).scaleEffect(iconPulse)
                        Image(systemName: type.icon).font(.system(size: 34, weight: .bold)).foregroundColor(type.color)
                    }
                    Text("Catch the \(type.label)")
                        .font(.system(size: 22, weight: .heavy, design: .rounded)).foregroundColor(.white)
                    Text(type.recycleCode).font(.system(size: 12)).foregroundColor(type.color.opacity(0.9))
                    Text("Slide the bin to intercept it before it hits the water")
                        .font(.system(size: 12)).foregroundColor(.white.opacity(0.5))
                        .multilineTextAlignment(.center).padding(.horizontal, 20)
                }
                Text("\(countdown)")
                    .font(.system(size: 80, weight: .heavy, design: .rounded)).foregroundColor(type.color)
                    .scaleEffect(countScale)
                    .onChange(of: countdown) { _, _ in
                        countScale = 0.4
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.5)) { countScale = 1.0 }
                    }
                    .onAppear {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.5)) { countScale = 1.0 }
                        withAnimation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true)) { iconPulse = 1.12 }
                    }
                    .accessibilityLabel("Starting in \(countdown)")
            }
            .padding(26)
            .background(RoundedRectangle(cornerRadius: 26)
                .fill(Color(red: 0.05, green: 0.13, blue: 0.27))
                .shadow(color: .black.opacity(0.4), radius: 20))
            .padding(.horizontal, 28)
        }
    }
}

struct GameResultCard: View {
    let success: Bool; let type: TrashType
    @State private var scale:      CGFloat = 0.6
    @State private var glowRadius: CGFloat = 0
    var body: some View {
        ZStack {
            Color.black.opacity(0.44).ignoresSafeArea()
            VStack(spacing: 10) {
                Text(success ? "✓" : "✕")
                    .font(.system(size: 54, weight: .heavy, design: .rounded))
                    .foregroundColor(success ? OceanTheme.seaGreen : OceanTheme.coral)
                    .shadow(color: (success ? OceanTheme.seaGreen : OceanTheme.coral).opacity(0.4), radius: glowRadius)
                Text(success ? "Saved from the ocean" : "It reached the water")
                    .font(.system(size: 18, weight: .bold, design: .rounded)).foregroundColor(.white)
                    .multilineTextAlignment(.center)
                if success {
                    Text(type.fact)
                        .font(.system(size: 12)).foregroundColor(.white.opacity(0.65))
                        .multilineTextAlignment(.center).padding(.horizontal, 24)
                }
            }
            .scaleEffect(scale)
            .onAppear {
                withAnimation(.spring(response: 0.32, dampingFraction: 0.55)) { scale = 1.0 }
                if success {
                    withAnimation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true).delay(0.2)) {
                        glowRadius = 18
                    }
                }
            }
        }
        .accessibilityLabel(success ? "Item caught. \(type.fact)" : "Item missed")
    }
}

struct GameSummaryView: View {
    @ObservedObject var engine: GameEngine
    let onDismiss: () -> Void; let onReplay: () -> Void
    @State private var shown = false
    
    var grade: (emoji: String, title: String, subtitle: String, color: Color) {
        if engine.isPerfect { return ("💎","Flawless","Not a single item reached the ocean.",Color(red:0.6,green:0.85,blue:1.0)) }
        switch engine.accuracy {
        case 80...100: return ("🏆","Ocean Hero","You protected the water well.",OceanTheme.teal)
        case 60...79:  return ("🌊","Guardian","A strong effort for the ocean.",Color(red:0.20,green:0.60,blue:1.00))
        case 40...59:  return ("🐢","Eco Learner","Keep practising — the ocean needs you.",OceanTheme.seaGreen)
        default:       return ("🌱","Keep Going","Every attempt teaches you more.",OceanTheme.coral)
        }
    }
    
    var uniqueTypes: [TrashType] {
        var seen = Set<String>(); return engine.rounds.filter { seen.insert($0.label).inserted }
    }
    
    var body: some View {
        ZStack {
            Color.black.opacity(0.70).ignoresSafeArea()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 20) {
                    VStack(spacing: 8) {
                        Text(grade.emoji).font(.system(size: 66))
                            .scaleEffect(shown ? 1 : 0.3)
                            .animation(.spring(response: 0.5, dampingFraction: 0.5).delay(0.1), value: shown)
                        if engine.isPerfect {
                            Text("PERFECT GAME")
                                .font(.system(size: 12, weight: .heavy)).foregroundColor(OceanTheme.gold).tracking(2)
                        }
                        Text(grade.title)
                            .font(.system(size: 24, weight: .heavy, design: .rounded)).foregroundColor(grade.color)
                        Text(grade.subtitle)
                            .font(.system(size: 13)).foregroundColor(.white.opacity(0.62)).multilineTextAlignment(.center)
                    }.padding(.top, 8)
                    
                    HStack(spacing: 10) {
                        SumTile(icon: "star.fill",  color: OceanTheme.gold,  label: "Score", value: "\(engine.score)")
                        SumTile(icon: "heart.fill", color: .red,              label: "Lives", value: "\(engine.lives)/3")
                        SumTile(icon: "bolt.fill",  color: OceanTheme.teal,  label: "Combo", value: "×\(engine.maxCombo)")
                    }
                    
                    VStack(alignment: .leading, spacing: 8) {
                        HStack {
                            Text("Accuracy").font(.system(size: 12, weight: .semibold)).foregroundColor(.white.opacity(0.6))
                            Spacer()
                            Text("\(engine.accuracy)%").font(.system(size: 12, weight: .bold)).foregroundColor(OceanTheme.teal)
                        }
                        GeometryReader { g in
                            ZStack(alignment: .leading) {
                                RoundedRectangle(cornerRadius: 5).fill(Color.white.opacity(0.08)).frame(height: 10)
                                RoundedRectangle(cornerRadius: 5)
                                    .fill(LinearGradient(colors: [OceanTheme.teal, OceanTheme.seaGreen],
                                                         startPoint: .leading, endPoint: .trailing))
                                    .frame(width: shown ? g.size.width * CGFloat(engine.accuracy) / 100 : 0, height: 10)
                                    .animation(.easeOut(duration: 1.0).delay(0.4), value: shown)
                            }
                        }.frame(height: 10)
                    }
                    .padding(14).background(Color.white.opacity(0.08)).cornerRadius(14)
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("What you sorted").font(.system(size: 13, weight: .bold)).foregroundColor(OceanTheme.teal)
                        ForEach(uniqueTypes) { type in
                            HStack(spacing: 10) {
                                ZStack {
                                    Circle().fill(type.color.opacity(0.18)).frame(width: 36, height: 36)
                                    Image(systemName: type.icon).font(.system(size: 14, weight: .bold)).foregroundColor(type.color)
                                }
                                VStack(alignment: .leading, spacing: 2) {
                                    Text(type.label).font(.system(size: 12, weight: .bold)).foregroundColor(.white)
                                    Text(type.fact).font(.system(size: 11)).foregroundColor(.white.opacity(0.58))
                                        .fixedSize(horizontal: false, vertical: true)
                                }
                            }
                        }
                    }
                    .padding(14).frame(maxWidth: .infinity, alignment: .leading)
                    .background(OceanTheme.teal.opacity(0.09)).cornerRadius(14)
                    .overlay(RoundedRectangle(cornerRadius: 14).stroke(OceanTheme.teal.opacity(0.22), lineWidth: 1))
                    
                    HStack(spacing: 8) {
                        Image(systemName: "drop.fill").foregroundColor(OceanTheme.teal)
                        Text("You helped keep an estimated \(engine.caughtCount * 18)g of plastic from the ocean today.")
                            .font(.system(size: 13)).foregroundColor(.white.opacity(0.75))
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(12).background(Color.white.opacity(0.06)).cornerRadius(12)
                    
                    VStack(spacing: 10) {
                        Button(action: onDismiss) {
                            Label("Back to Dashboard", systemImage: "house.fill")
                                .font(.system(size: 17, weight: .bold, design: .rounded)).foregroundColor(.white)
                                .frame(maxWidth: .infinity).frame(height: 52)
                                .background(LinearGradient(colors: [OceanTheme.teal, OceanTheme.seaGreen],
                                                           startPoint: .leading, endPoint: .trailing))
                                .cornerRadius(16).shadow(color: OceanTheme.teal.opacity(0.45), radius: 10, x: 0, y: 5)
                        }
                        Button(action: onReplay) {
                            Label("Play Again", systemImage: "arrow.clockwise")
                                .font(.system(size: 15, weight: .semibold)).foregroundColor(.white.opacity(0.82))
                                .frame(maxWidth: .infinity).frame(height: 46)
                                .background(Color.white.opacity(0.10)).cornerRadius(14)
                        }
                    }
                }
                .padding(22)
            }
            .background(RoundedRectangle(cornerRadius: 28)
                .fill(Color(red: 0.05, green: 0.12, blue: 0.25)).shadow(color: .black.opacity(0.5), radius: 28))
            .padding(.horizontal, 12).padding(.vertical, 18)
            .scaleEffect(shown ? 1 : 0.92).opacity(shown ? 1 : 0)
            .onAppear { withAnimation(.spring(response: 0.5, dampingFraction: 0.72)) { shown = true } }
        }
    }
}

struct SumTile: View {
    let icon: String; let color: Color; let label: String; let value: String
    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon).font(.system(size: 16)).foregroundColor(color)
            Text(value).font(.system(size: 16, weight: .heavy, design: .rounded)).foregroundColor(.white)
                .contentTransition(.numericText())
            Text(label).font(.system(size: 10)).foregroundColor(.white.opacity(0.52))
        }
        .frame(maxWidth: .infinity).padding(12)
        .background(Color.white.opacity(0.08)).cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(color.opacity(0.22), lineWidth: 1))
    }
}

struct GameWavesBG: View {
    @State private var phase: CGFloat = 0
    var body: some View {
        VStack {
            Spacer()
            ZStack {
                GWave(phase: phase, amp: 10, freq: 1.4)
                    .fill(Color(red: 0, green: 0.50, blue: 0.66).opacity(0.22)).frame(height: 80)
                GWave(phase: phase + 1.1, amp: 7, freq: 1.9)
                    .fill(Color(red: 0, green: 0.60, blue: 0.76).opacity(0.15)).frame(height: 80)
            }
        }
        .ignoresSafeArea()
        .onAppear {
            withAnimation(.linear(duration: 3.5).repeatForever(autoreverses: false)) { phase = .pi * 2 }
        }
    }
}

struct GWave: Shape {
    var phase: CGFloat; var amp: CGFloat; var freq: CGFloat
    var animatableData: CGFloat { get { phase } set { phase = newValue } }
    func path(in rect: CGRect) -> Path {
        var p = Path()
        let mid = rect.height / 2
        p.move(to: CGPoint(x: 0, y: mid))
        for x in stride(from: 0, through: rect.width, by: 2) {
            p.addLine(to: CGPoint(x: x, y: mid + amp * sin(freq * (.pi*2/rect.width) * x + phase)))
        }
        p.addLine(to: CGPoint(x: rect.width, y: rect.height))
        p.addLine(to: CGPoint(x: 0, y: rect.height))
        p.closeSubpath(); return p
    }
}

struct PlasticSavedPopup: View {
    let grams:          Double
    let caughtCount:    Int
    let popupScale:     CGFloat
    let ringPulse:      CGFloat
    let particleActive: Bool
    let onDismiss:      () -> Void
    
    @State private var numberShown: Double = 0
    @State private var ripple1: CGFloat    = 0.3
    @State private var ripple2: CGFloat    = 0.3
    @State private var ripple1Opacity      = 0.7
    @State private var ripple2Opacity      = 0.5
    @State private var checkScale: CGFloat = 0.2
    @State private var checkOpacity        = 0.0
    @State private var subtitleShown       = false
    
    var body: some View {
        ZStack {
            // Dim background
            Color.black.opacity(0.72).ignoresSafeArea()
                .onTapGesture { onDismiss() }
            
            VStack(spacing: 0) {
                Spacer()
                
                VStack(spacing: 22) {
                    // ── Ripple ring + checkmark ────────────────
                    ZStack {
                        // Ripple 1
                        Circle()
                            .stroke(OceanTheme.teal.opacity(ripple1Opacity), lineWidth: 2)
                            .frame(width: 180 * ripple1, height: 180 * ripple1)
                        // Ripple 2
                        Circle()
                            .stroke(OceanTheme.seaGreen.opacity(ripple2Opacity), lineWidth: 1.5)
                            .frame(width: 220 * ripple2, height: 220 * ripple2)
                        // Pulsing ring
                        Circle()
                            .stroke(
                                LinearGradient(
                                    colors: [OceanTheme.teal, OceanTheme.seaGreen],
                                    startPoint: .topLeading, endPoint: .bottomTrailing),
                                lineWidth: 5)
                            .frame(width: 130, height: 130)
                            .scaleEffect(ringPulse)
                        // Particles
                        ForEach(0..<12) { i in
                            Circle()
                                .fill(i % 2 == 0 ? OceanTheme.teal : OceanTheme.gold)
                                .frame(width: 7, height: 7)
                                .offset(
                                    x: particleActive
                                    ? cos(Double(i) / 12 * .pi * 2) * 88
                                    : 0,
                                    y: particleActive
                                    ? sin(Double(i) / 12 * .pi * 2) * 88
                                    : 0
                                )
                                .opacity(particleActive ? 0 : 0.9)
                                .animation(
                                    .easeOut(duration: 0.7).delay(Double(i) * 0.03),
                                    value: particleActive
                                )
                        }
                        // Checkmark
                        Image(systemName: "checkmark.circle.fill")
                            .font(.system(size: 62, weight: .bold))
                            .foregroundColor(OceanTheme.teal)
                            .shadow(color: OceanTheme.teal.opacity(0.5), radius: 18)
                            .scaleEffect(checkScale)
                            .opacity(checkOpacity)
                    }
                    .frame(width: 230, height: 230)
                    
                    // ── "Plastic Saved!" heading ──────────────
                    VStack(spacing: 6) {
                        Text("Plastic Saved! 🌊")
                            .font(.system(size: 26, weight: .heavy, design: .rounded))
                            .foregroundColor(.white)
                        // Animated gram counter
                        Text(String(format: "+%.1f g", numberShown))
                            .font(.system(size: 44, weight: .heavy, design: .rounded))
                            .foregroundColor(OceanTheme.teal)
                            .contentTransition(.numericText())
                            .shadow(color: OceanTheme.teal.opacity(0.4), radius: 12)
                    }
                    
                    // ── Details ──────────────────────────────
                    if subtitleShown {
                        VStack(spacing: 8) {
                            HStack(spacing: 14) {
                                SavedStatChip(
                                    icon: "archivebox.fill",
                                    color: OceanTheme.teal,
                                    value: "\(caughtCount)",
                                    label: "Items Rescued"
                                )
                                SavedStatChip(
                                    icon: "drop.fill",
                                    color: OceanTheme.seaGreen,
                                    value: String(format: "%.1fg", grams),
                                    label: "Kept from Ocean"
                                )
                            }
                            Text("Every piece you caught is one less fragment\nthat a sea creature would have encountered.")
                                .font(.system(size: 12, weight: .medium))
                                .foregroundColor(.white.opacity(0.62))
                                .multilineTextAlignment(.center)
                                .padding(.horizontal, 8)
                        }
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                    }
                    
                    // ── Progress ring preview ─────────────────
                    DailyProgressRingMini(addedGrams: grams)
                        .transition(.scale.combined(with: .opacity))
                    
                    // ── CTA ───────────────────────────────────
                    Button(action: onDismiss) {
                        Text("Back to Dashboard →")
                            .font(.system(size: 17, weight: .bold, design: .rounded))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity).frame(height: 52)
                            .background(
                                LinearGradient(
                                    colors: [OceanTheme.teal, OceanTheme.seaGreen],
                                    startPoint: .leading, endPoint: .trailing)
                            )
                            .cornerRadius(16)
                            .shadow(color: OceanTheme.teal.opacity(0.45), radius: 12, x: 0, y: 5)
                    }
                    .padding(.horizontal, 8)
                    .padding(.top, 4)
                    .accessibilityLabel("Return to dashboard")
                }
                .padding(26)
                .background(
                    RoundedRectangle(cornerRadius: 28)
                        .fill(Color(red: 0.04, green: 0.11, blue: 0.24))
                        .shadow(color: OceanTheme.teal.opacity(0.25), radius: 30, x: 0, y: 8)
                )
                .padding(.horizontal, 18)
                .scaleEffect(popupScale)
                
                Spacer()
            }
        }
        .onAppear {
            // Ripple animations
            withAnimation(.easeOut(duration: 1.0).repeatForever(autoreverses: false)) {
                ripple1 = 1.0; ripple1Opacity = 0
            }
            withAnimation(.easeOut(duration: 1.0).delay(0.4).repeatForever(autoreverses: false)) {
                ripple2 = 1.0; ripple2Opacity = 0
            }
            // Checkmark pop in
            withAnimation(.spring(response: 0.4, dampingFraction: 0.5).delay(0.15)) {
                checkScale = 1.0; checkOpacity = 1.0
            }
            // Count-up animation
            withAnimation(.easeOut(duration: 1.2).delay(0.4)) {
                numberShown = grams
            }
            // Subtitle slide up
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
                withAnimation(.spring(response: 0.5, dampingFraction: 0.75)) {
                    subtitleShown = true
                }
            }
        }
    }
}

// ── Stat chip inside popup ────────────────────────────────────────
struct SavedStatChip: View {
    let icon: String; let color: Color; let value: String; let label: String
    var body: some View {
        VStack(spacing: 4) {
            Image(systemName: icon).font(.system(size: 15)).foregroundColor(color)
            Text(value)
                .font(.system(size: 16, weight: .heavy, design: .rounded)).foregroundColor(.white)
            Text(label).font(.system(size: 9)).foregroundColor(.white.opacity(0.5))
        }
        .frame(maxWidth: .infinity).padding(.vertical, 10)
        .background(color.opacity(0.12)).cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(color.opacity(0.25), lineWidth: 1))
    }
}

// ── Mini ring preview ─────────────────────────────────────────────
struct DailyProgressRingMini: View {
    let addedGrams: Double
    @State private var pct: CGFloat = 0
    private let target = EcoConfiguration.dailyGoalTarget
    
    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle().stroke(Color.white.opacity(0.10), lineWidth: 8)
                Circle()
                    .trim(from: 0, to: pct)
                    .stroke(
                        AngularGradient(
                            colors: [OceanTheme.teal, OceanTheme.seaGreen, OceanTheme.teal],
                            center: .center),
                        style: StrokeStyle(lineWidth: 8, lineCap: .round)
                    )
                    .rotationEffect(.degrees(-90))
                    .animation(.easeOut(duration: 1.0).delay(0.5), value: pct)
                Text("\(Int(pct * 100))%")
                    .font(.system(size: 13, weight: .heavy, design: .rounded))
                    .foregroundColor(.white)
                    .contentTransition(.numericText())
                    .animation(.easeOut(duration: 1.0).delay(0.5), value: pct)
            }
            .frame(width: 62, height: 62)
            
            VStack(alignment: .leading, spacing: 3) {
                Text("Daily Goal Progress")
                    .font(.system(size: 12, weight: .bold)).foregroundColor(.white)
                Text("+\(String(format: "%.1f", addedGrams))g added from this game")
                    .font(.system(size: 11)).foregroundColor(OceanTheme.teal)
                Text("Ring updates on your dashboard")
                    .font(.system(size: 10)).foregroundColor(.white.opacity(0.45))
            }
            Spacer()
        }
        .padding(12)
        .background(Color.white.opacity(0.06))
        .cornerRadius(14)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                pct = CGFloat(min(addedGrams / target, 1.0))
            }
        }
    }
}
