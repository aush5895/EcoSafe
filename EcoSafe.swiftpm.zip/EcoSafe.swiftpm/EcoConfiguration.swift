import SwiftUI

struct EcoConfiguration {
    
    static let dailyGoalTarget: Double      = 25.0   
    static let gramsPerScan: Double         = 5.0    
    
    static let initialOceanHealth: Double   = 0.35
    static let healthGainPerScan: Double    = 0.03
    static let healthGainPerCatch: Double   = 0.012
    static let healthLossPerMiss: Double    = 0.018
    static let healthFlourishing: Double    = 0.85
    static let healthRecovering: Double     = 0.60
    static let healthStabilizing: Double    = 0.40
    static let healthPolluted: Double       = 0.20
    
    static let thresholdFirstScan: Double   = 5.0
    static let thresholdScans5: Double      = 25.0
    static let thresholdPlastic50: Double   = 50.0
    static let thresholdStreak3: Int        = 3
    static let thresholdStreak7: Int        = 7
    static let thresholdFlashcards: Int     = 12
    static let thresholdOceanHero: Double   = 0.85
    
    static let gameTotalRounds: Int          = 6
    static let gameTimeLimit: Double         = 30.0
    static let gameInitialFallSpeed: Double  = 165.0
    static let gameMaxFallSpeed: Double      = 310.0
    static let gameSpeedIncrement: Double    = 10.0
    static let gameCatchWindow: CGFloat      = 62.0
    static let gameCountdownDelay: Double    = 0.95
    static let gameResultDisplayTime: Double = 1.15
    static let gameBasePoints: Int           = 10
    static let gameTimeBonusMax: Int         = 5
    static let gameMaxComboMultiplier: Int   = 8
    static let scoreComboMultiplierBase: Int = 1
    
    static let animSplashDuration: Double    = 1.1
    static let animHeaderDelay: Double       = 0.12
    static let animCardsDelay: Double        = 0.36
    static let animRingDelay: Double         = 0.4
    static let animRingDuration: Double      = 1.1
    static let animWaveDuration: Double      = 4.5
    static let animBubbleMinDuration: Double = 4.5
    static let animBubbleMaxDuration: Double = 9.0
    static let animScanAutoDetect: Double    = 2.6
    static let animParallaxRange: CGFloat    = 12.0
    
    static let audioLowHealthThreshold: Double  = 0.25
    static let audioHighHealthThreshold: Double  = 0.85
    static let audioFadeInDuration: Double       = 2.0
    static let audioFadeOutDuration: Double      = 1.5
    
    static let weeklyConsistencyTarget: Int     = 5
    
    static let motivationalQuotes: [String] = [
        "The ocean doesn't ask for much — just your consistency.",
        "Every gram intercepted is a life spared beneath the waves.",
        "Small actions, compounded daily, change ecosystems.",
        "The fish remember what you do today.",
        "One habit. One ocean. One future.",
        "Plastic is a choice. You're making the right one.",
        "Coral grows back when people pay attention.",
        "You are the intervention the ocean has been waiting for.",
        "Rivers carry your choices to the sea. Choose well.",
        "Nature doesn't forgive easily — but it never forgets effort."
    ]
    
    static func dailyQuote() -> String {
        let dayOfYear = Calendar.current.ordinality(of: .day, in: .year, for: Date()) ?? 1
        let index = (dayOfYear - 1) % motivationalQuotes.count
        return motivationalQuotes[index]
    }
    
    static func streakMessage(for days: Int) -> String {
        switch days {
        case 0:       return "Start today — the ocean is waiting."
        case 1:       return "First day. The journey begins."
        case 2...3:   return "Building momentum. Don't break the chain."
        case 4...6:   return "A solid habit is forming. Keep going."
        case 7...13:  return "One week strong. The ocean notices."
        case 14...29: return "Two weeks of consistency. You're different now."
        case 30...:   return "A month of dedication. You're part of the solution."
        default:      return "Keep the streak alive."
        }
    }
    
    static func oceanPhase(for health: Double) -> OceanPhase {
        switch health {
        case ..<healthPolluted:    return .polluted
        case ..<healthStabilizing: return .stabilizing
        case ..<healthRecovering:  return .recovering
        case ..<healthFlourishing: return .flourishing
        default:                   return .thriving
        }
    }
}

enum OceanPhase: Equatable {
    case polluted, stabilizing, recovering, flourishing, thriving
    
    var label: String {
        switch self {
        case .polluted:    return "Polluted"
        case .stabilizing: return "Stabilizing"
        case .recovering:  return "Recovering"
        case .flourishing: return "Flourishing"
        case .thriving:    return "Thriving"
        }
    }
    
    var color: Color {
        switch self {
        case .polluted:    return Color(red: 1.00, green: 0.45, blue: 0.35)
        case .stabilizing: return Color(red: 1.00, green: 0.82, blue: 0.22)
        case .recovering:  return Color(red: 0.20, green: 0.72, blue: 0.62)
        case .flourishing: return Color(red: 0.00, green: 0.72, blue: 0.80)
        case .thriving:    return Color(red: 0.30, green: 0.90, blue: 0.75)
        }
    }
    
    var narrativeHeadline: String {
        switch self {
        case .polluted:    return "The ocean is struggling."
        case .stabilizing: return "The water is slowly clearing."
        case .recovering:  return "Marine life is returning."
        case .flourishing: return "The ecosystem is healing."
        case .thriving:    return "The ocean is thriving."
        }
    }
    
    var narrativeBody: String {
        switch self {
        case .polluted:    return "Scan more items and play Ocean Rescue to begin the recovery."
        case .stabilizing: return "Your actions are creating a measurable difference."
        case .recovering:  return "Coral is growing back. Fish are re-appearing."
        case .flourishing: return "The reef is alive with colour. Keep going."
        case .thriving:    return "You've transformed this ecosystem. The ocean remembers."
        }
    }
    
    var uiAccentOpacity: Double {
        switch self {
        case .polluted:    return 0.55
        case .stabilizing: return 0.68
        case .recovering:  return 0.78
        case .flourishing: return 0.88
        case .thriving:    return 1.00
        }
    }
    
    var ambientIntensity: Double {
        switch self {
        case .polluted:    return 0.30
        case .stabilizing: return 0.45
        case .recovering:  return 0.60
        case .flourishing: return 0.75
        case .thriving:    return 1.00
        }
    }
}
