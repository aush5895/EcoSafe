import SwiftUI

enum TrashType: String, CaseIterable, Identifiable {
    case plastic, paper, metal, glass, organic
    
    var id: String { rawValue }
    
    var icon: String {
        switch self {
        case .plastic: return "waterbottle.fill"
        case .paper:   return "doc.fill"
        case .metal:   return "cylinder.fill"
        case .glass:   return "wineglass.fill"
        case .organic: return "leaf.fill"
        }
    }
    
    var label: String { rawValue.capitalized }
    
    var color: Color {
        switch self {
        case .plastic: return Color(red: 0.20, green: 0.65, blue: 1.00)
        case .paper:   return Color(red: 1.00, green: 0.80, blue: 0.20)
        case .metal:   return Color(red: 0.75, green: 0.75, blue: 0.82)
        case .glass:   return Color(red: 0.30, green: 0.88, blue: 0.68)
        case .organic: return Color(red: 0.55, green: 0.82, blue: 0.28)
        }
    }
    
    var fact: String {
        switch self {
        case .plastic: return "Plastic takes 450 years to decompose — it outlives every person alive today."
        case .paper:   return "Paper can be recycled up to 7 times before the fibres become too short."
        case .metal:   return "Aluminium cans can be recycled forever without any loss of quality."
        case .glass:   return "Glass is 100% recyclable and never loses purity through the process."
        case .organic: return "Composting organic waste prevents harmful methane release into the atmosphere."
        }
    }
    
    var recycleCode: String {
        switch self {
        case .plastic: return "Rinse · Recycle #1–2"
        case .paper:   return "Keep dry and clean"
        case .metal:   return "Rinse and crush"
        case .glass:   return "Sort by colour"
        case .organic: return "Compost bin"
        }
    }
}

enum GamePhase: Equatable {
    case idle, countdown, playing, result, summary
}

struct ScorePopupItem: Identifiable {
    let id       = UUID()
    let text:    String
    var position: CGPoint
    let color:   Color
    var age:     Double = 0
    
    var opacity: Double  { max(0, 1.0 - age) }
    var yOffset: CGFloat { CGFloat(-age * 55) }
}

final class GameEngine: ObservableObject {
    
    @Published var phase: GamePhase          = .idle
    @Published var score: Int                = 0
    @Published var combo: Int                = 1
    @Published var maxCombo: Int             = 1
    @Published var lives: Int                = 3
    @Published var gameTimeRemaining: Double
    @Published var countdownValue: Int       = 3
    @Published var binX: CGFloat             = 195
    @Published var trashX: CGFloat           = 195
    @Published var trashY: CGFloat           = -60
    @Published var activeRound: Int          = 0
    @Published var resultIsSuccess: Bool     = true
    @Published var missedCount: Int          = 0
    @Published var rounds: [TrashType]       = []
    @Published var isDragging: Bool          = false
    @Published var binTrail: [CGFloat]       = []
    @Published var showSplash: Bool          = false
    @Published var splashPos: CGPoint        = .zero
    @Published var splashColor: Color        = .blue
    @Published var scorePopups: [ScorePopupItem] = []
    
    private var lastTickDate:   Date?   = nil
    private var countdownAccum: Double  = 0
    private var resultAccum:    Double  = 0
    private var splashAccum:    Double  = 0
    private var fallSpeed:      Double
    private var screenSize:     CGSize  = CGSize(width: 390, height: 844)
    
    let totalRounds:       Int    = EcoConfiguration.gameTotalRounds
    let gameTimeLimit:     Double = EcoConfiguration.gameTimeLimit
    let resultDisplayTime: Double = EcoConfiguration.gameResultDisplayTime
    let countdownDelay:    Double = EcoConfiguration.gameCountdownDelay
    
    init() {
        gameTimeRemaining = EcoConfiguration.gameTimeLimit
        fallSpeed         = EcoConfiguration.gameInitialFallSpeed
    }
    
    var currentType: TrashType {
        guard !rounds.isEmpty, activeRound < rounds.count else { return .plastic }
        return rounds[activeRound]
    }
    var binTop: CGFloat     { screenSize.height - 125 }
    var caughtCount: Int    { totalRounds - missedCount }
    var accuracy: Int       { totalRounds > 0 ? Int(Double(caughtCount) / Double(totalRounds) * 100) : 0 }
    var isPerfect: Bool     { missedCount == 0 }
    
    func startGame() {
        generateRounds()
        phase             = .countdown
        countdownValue    = 3
        countdownAccum    = 0
        gameTimeRemaining = gameTimeLimit
        score = 0; combo = 1; maxCombo = 1
        lives = 3; activeRound = 0; missedCount = 0
        fallSpeed         = EcoConfiguration.gameInitialFallSpeed
        lastTickDate      = nil
        binTrail          = []
        scorePopups       = []
        resetTrash()
    }
    
    func restart() { startGame() }
    
    private func generateRounds() {
        var pool = TrashType.allCases.shuffled()
        while pool.count < totalRounds { pool += TrashType.allCases.shuffled() }
        rounds = Array(pool.prefix(totalRounds))
    }
    
    private func resetTrash() {
        trashX = CGFloat.random(in: 60...(max(61, screenSize.width - 60)))
        trashY = -60
    }
    
    func tick(date: Date, size: CGSize) {
        screenSize = size
        if binX == 195 { binX = size.width / 2 }
        guard let last = lastTickDate else { lastTickDate = date; return }
        let dt = min(date.timeIntervalSince(last), 0.05)
        lastTickDate = date
        
        switch phase {
        case .countdown: tickCountdown(dt: dt)
        case .playing:   tickPlaying(dt: dt)
        case .result:    tickResult(dt: dt)
        default:         break
        }
        
        if showSplash {
            splashAccum += dt
            if splashAccum > 0.65 { showSplash = false; splashAccum = 0 }
        }
        
        scorePopups = scorePopups
            .map    { var p = $0; p.age += dt; return p }
            .filter { $0.age <= 1.0 }
    }
    
    private func tickCountdown(dt: Double) {
        countdownAccum += dt
        if countdownAccum >= countdownDelay {
            countdownAccum = 0
            if countdownValue > 1 {
                countdownValue -= 1
                SoundManager.shared.hapticLight()
            } else {
                resetTrash()
                phase = .playing
            }
        }
    }
    
    private func tickPlaying(dt: Double) {
        gameTimeRemaining -= dt
        if gameTimeRemaining <= 0 { gameTimeRemaining = 0; finishGame(); return }
        trashY += CGFloat(fallSpeed * dt)
        let caught = abs(trashX - binX) < EcoConfiguration.gameCatchWindow && trashY >= binTop
        if caught                               { handleCatch() }
        else if trashY > screenSize.height + 60 { handleMiss()  }
    }
    
    private func tickResult(dt: Double) {
        resultAccum += dt
        if resultAccum >= resultDisplayTime { resultAccum = 0; advance() }
    }
    
    func moveBin(to x: CGFloat) {
        let clamped = max(50, min(screenSize.width - 50, x))
        binTrail.append(binX)
        if binTrail.count > 5 { binTrail.removeFirst() }
        binX = clamped
    }
    
    func endDrag() { isDragging = false; binTrail = [] }
    
    private func handleCatch() {
        let timeBonus   = Int((gameTimeRemaining / gameTimeLimit) * Double(EcoConfiguration.gameTimeBonusMax))
        let pts         = (EcoConfiguration.gameBasePoints + timeBonus) * combo
        score          += pts
        combo           = min(combo + 1, EcoConfiguration.gameMaxComboMultiplier)
        maxCombo        = max(maxCombo, combo)
        resultIsSuccess = true
        fallSpeed       = min(fallSpeed + EcoConfiguration.gameSpeedIncrement, EcoConfiguration.gameMaxFallSpeed)
        splashPos   = CGPoint(x: binX, y: binTop)
        splashColor = currentType.color
        showSplash  = true
        splashAccum = 0
        let popupLabel = combo > 2 ? "+\(pts) ×\(combo - 1)" : "+\(pts)"
        addPopup(popupLabel, at: CGPoint(x: trashX, y: binTop - 28), color: .green)
        SoundManager.shared.playSuccess()
        phase = .result
    }
    
    private func handleMiss() {
        lives       -= 1
        combo        = 1
        missedCount += 1
        resultIsSuccess = false
        addPopup("Miss", at: CGPoint(x: trashX, y: screenSize.height - 110), color: .red)
        SoundManager.shared.playMiss()
        if lives <= 0 { finishGame() } else { phase = .result }
    }
    
    private func advance() {
        if activeRound >= totalRounds - 1 { finishGame() }
        else { activeRound += 1; resetTrash(); phase = .playing }
    }
    
    func finishGame() { phase = .summary; lastTickDate = nil }
    
    private func addPopup(_ text: String, at pos: CGPoint, color: Color) {
        scorePopups.append(ScorePopupItem(text: text, position: pos, color: color))
    }
}
