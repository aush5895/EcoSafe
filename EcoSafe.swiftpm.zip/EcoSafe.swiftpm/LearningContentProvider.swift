import SwiftUI

enum FlashCardCategory: String, CaseIterable {
    case plastics      = "Plastics"
    case ocean         = "Ocean Impact"
    case recycling     = "Recycling"
    case materials     = "Materials"
    case microplastics = "Microplastics"
    case behavior      = "Behaviour"
    
    var icon: String {
        switch self {
        case .plastics:      return "waterbottle.fill"
        case .ocean:         return "water.waves"
        case .recycling:     return "arrow.3.trianglepath"
        case .materials:     return "shippingbox.fill"
        case .microplastics: return "microbe.fill"
        case .behavior:      return "person.fill.checkmark"
        }
    }
    
    var color: Color {
        switch self {
        case .plastics:      return Color(red: 0.00, green: 0.72, blue: 0.80)
        case .ocean:         return Color(red: 0.06, green: 0.22, blue: 0.64)
        case .recycling:     return Color(red: 0.13, green: 0.72, blue: 0.52)
        case .materials:     return Color(red: 1.00, green: 0.82, blue: 0.22)
        case .microplastics: return Color(red: 0.78, green: 0.30, blue: 0.22)
        case .behavior:      return Color(red: 0.42, green: 0.22, blue: 0.80)
        }
    }
}

struct FlashCard: Identifiable {
    let id             = UUID()
    let emoji:         String
    let frontTitle:    String
    let frontSubtitle: String
    let backFact:      String
    let backTip:       String
    let color:         Color
    let category:      FlashCardCategory
    let localizedKey:  String
}

struct LearningContentProvider {
    
    static var allCards: [FlashCard] { coreCards }
    
    private static let coreCards: [FlashCard] = [
        
        FlashCard(
            emoji:         "🧴",
            frontTitle:    "What is PET plastic?",
            frontSubtitle: "The most common plastic you touch",
            backFact:      "PET (Type #1) is the most widely recycled plastic in the world — used in water bottles, food trays, and clear packaging.",
            backTip:       "Rinse before recycling. Even a few drops of liquid can cause an entire batch to be rejected at a sorting facility.",
            color:         FlashCardCategory.plastics.color,
            category:      .plastics,
            localizedKey:  "card.pet_plastic"
        ),
        FlashCard(
            emoji:         "🧃",
            frontTitle:    "Why can't you recycle Tetra Pak?",
            frontSubtitle: "The packaging that confuses everyone",
            backFact:      "Tetra Pak is made of 6 layers — paper, aluminium, and plastic fused together. Most standard facilities can't separate them.",
            backTip:       "Find a specialist Tetra Pak collection point. Some supermarkets and councils accept them via dedicated schemes.",
            color:         FlashCardCategory.plastics.color,
            category:      .plastics,
            localizedKey:  "card.tetrapak"
        ),
        FlashCard(
            emoji:         "🛍️",
            frontTitle:    "Plastic bags",
            frontSubtitle: "12 minutes used — 20 years to break down",
            backFact:      "A plastic bag used for just 12 minutes takes up to 20 years to decompose — and even then only into harmful microplastic fragments.",
            backTip:       "Return soft plastics (bags, cling film, bubble wrap) to supermarket drop-off points. Never put them in your curbside bin.",
            color:         FlashCardCategory.behavior.color,
            category:      .behavior,
            localizedKey:  "card.plastic_bags"
        ),
        
        FlashCard(
            emoji:         "🌊",
            frontTitle:    "How long does a plastic bottle last?",
            frontSubtitle: "Longer than every person alive today",
            backFact:      "A single plastic bottle takes up to 450 years to decompose — it will outlast every living human being on Earth many times over.",
            backTip:       "Switch to one reusable bottle. Over a year that prevents approximately 156 single-use bottles from entering production.",
            color:         FlashCardCategory.ocean.color,
            category:      .ocean,
            localizedKey:  "card.bottle_lifespan"
        ),
        FlashCard(
            emoji:         "🐠",
            frontTitle:    "Ocean plastic and marine life",
            frontSubtitle: "The hidden cost every item carries",
            backFact:      "Over 1 million seabirds and 100,000 marine mammals die from plastic entanglement or ingestion every single year.",
            backTip:       "Avoid single-use straws, cutlery, and bags. These are the primary entanglement offenders — they enter waterways within hours.",
            color:         FlashCardCategory.ocean.color,
            category:      .ocean,
            localizedKey:  "card.marine_impact"
        ),
        FlashCard(
            emoji:         "🪸",
            frontTitle:    "Plastic and coral reefs",
            frontSubtitle: "A threat beneath the surface",
            backFact:      "Plastic debris increases coral disease risk by up to 89%. It blocks sunlight, carries pathogens, and smothers the reef structure.",
            backTip:       "Coral can recover if pollution is reduced. Every piece of plastic kept from the ocean gives reefs a real chance at survival.",
            color:         FlashCardCategory.ocean.color,
            category:      .ocean,
            localizedKey:  "card.coral_plastic"
        ),
        
        FlashCard(
            emoji:         "♻️",
            frontTitle:    "The recycling triangle numbers",
            frontSubtitle: "What do they actually mean?",
            backFact:      "Numbers #1 (PET) and #2 (HDPE) are accepted almost everywhere. #3 (PVC) and #6 (PS/polystyrene) are rarely recyclable.",
            backTip:       "Check the number before every sort. When in doubt, check your local council's guidance — rules vary by area.",
            color:         FlashCardCategory.recycling.color,
            category:      .recycling,
            localizedKey:  "card.recycling_numbers"
        ),
        FlashCard(
            emoji:         "🥫",
            frontTitle:    "Why aluminium is the best recyclable",
            frontSubtitle: "The material that never wears out",
            backFact:      "Aluminium can be recycled infinitely — it never loses quality or purity. Recycling it uses just 5% of the energy of making it new.",
            backTip:       "Rinse your cans, crush them to save space, and always separate from other materials. They're worth recycling every single time.",
            color:         FlashCardCategory.recycling.color,
            category:      .recycling,
            localizedKey:  "card.aluminium"
        ),
        FlashCard(
            emoji:         "🔬",
            frontTitle:    "What are microplastics?",
            frontSubtitle: "Invisible — but everywhere",
            backFact:      "Particles under 5 mm — found in human blood, breast milk, drinking water, deep-sea sediment, and unborn foetuses worldwide.",
            backTip:       "Correctly recycling large plastics prevents them fragmenting into these invisible, pervasive particles over time.",
            color:         FlashCardCategory.microplastics.color,
            category:      .microplastics,
            localizedKey:  "card.microplastics"
        ),
        FlashCard(
            emoji:         "👕",
            frontTitle:    "Synthetic clothes and microplastics",
            frontSubtitle: "What your washing machine releases",
            backFact:      "A single synthetic garment can shed up to 700,000 microplastic fibres in one wash — most pass straight through treatment plants into the ocean.",
            backTip:       "Use a microplastic-catching laundry bag (e.g. Guppyfriend). Wash at lower temperatures and spin speeds to reduce shedding.",
            color:         FlashCardCategory.microplastics.color,
            category:      .microplastics,
            localizedKey:  "card.synthetic_clothes"
        ),
        
        FlashCard(
            emoji:         "📄",
            frontTitle:    "Paper recycling",
            frontSubtitle: "7 lives, then it's done",
            backFact:      "Paper can be recycled up to 7 times before its fibres become too short to bond. After that, it becomes mulch or compost.",
            backTip:       "Keep paper dry and clean — wet or greasy paper (like pizza boxes) cannot be recycled. Dry the clean portion and recycle that separately.",
            color:         FlashCardCategory.materials.color,
            category:      .materials,
            localizedKey:  "card.paper"
        ),
        FlashCard(
            emoji:         "🍃",
            frontTitle:    "Why composting matters",
            frontSubtitle: "The alternative to landfill",
            backFact:      "Food and organic waste in landfill produces methane — a greenhouse gas 84× more potent than CO₂ over 20 years. Composting prevents this.",
            backTip:       "Use a compost bin or food caddy for peelings, coffee grounds, and eggshells. Most councils collect food waste weekly.",
            color:         FlashCardCategory.materials.color,
            category:      .materials,
            localizedKey:  "card.composting"
        ),
    ]
    
    static func cards(for category: FlashCardCategory) -> [FlashCard] {
        coreCards.filter { $0.category == category }
    }
    
    static var totalCount: Int { coreCards.count }
}
