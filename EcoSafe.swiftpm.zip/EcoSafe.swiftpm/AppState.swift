import SwiftUI

final class AppState: ObservableObject {
    
    @Published var totalPlastic: Double {
        didSet { UserDefaults.standard.set(totalPlastic, forKey: "v2.totalPlastic") }
    }
    @Published var streakDays: Int {
        didSet { UserDefaults.standard.set(streakDays, forKey: "v2.streakDays") }
    }
    @Published var lastActiveDateString: String {
        didSet { UserDefaults.standard.set(lastActiveDateString, forKey: "v2.lastActiveDate") }
    }
    @Published var weeklyScans: [Double] {
        didSet { UserDefaults.standard.set(weeklyScans, forKey: "v2.weeklyScans") }
    }
    @Published var lifetimeScans: [String: Double] {
        didSet {
            if let data = try? JSONEncoder().encode(lifetimeScans) {
                UserDefaults.standard.set(data, forKey: "v2.lifetimeScans")
            }
        }
    }
    @Published var flashcardsLearned: Int {
        didSet { UserDefaults.standard.set(flashcardsLearned, forKey: "v2.flashcardsLearned") }
    }
    @Published var gamesPlayed: Int {
        didSet { UserDefaults.standard.set(gamesPlayed, forKey: "v2.gamesPlayed") }
    }
    @Published var perfectGames: Int {
        didSet { UserDefaults.standard.set(perfectGames, forKey: "v2.perfectGames") }
    }
    @Published var achievementFlags: [String: Bool] {
        didSet { UserDefaults.standard.set(achievementFlags, forKey: "v2.achievementFlags") }
    }
    @Published var oceanHealthRaw: Double {
        didSet { UserDefaults.standard.set(oceanHealthRaw, forKey: "v2.oceanHealth") }
    }
    @Published var hasSeenIntro: Bool {
        didSet { UserDefaults.standard.set(hasSeenIntro, forKey: "v2.hasSeenIntro") }
    }
    @Published var hasSeenOutro: Bool {
        didSet { UserDefaults.standard.set(hasSeenOutro, forKey: "v2.hasSeenOutro") }
    }
    @Published var dailyGoalProgress: Double {
        didSet { UserDefaults.standard.set(dailyGoalProgress, forKey: "v2.dailyGoalProgress") }
    }
    @Published var lastDailyResetString: String {
        didSet { UserDefaults.standard.set(lastDailyResetString, forKey: "v2.lastDailyReset") }
    }
    @Published var weeklyActiveDays: [String] {
        didSet { UserDefaults.standard.set(weeklyActiveDays, forKey: "v2.weeklyActiveDays") }
    }
    @Published var totalScansCount: Int {
        didSet { UserDefaults.standard.set(totalScansCount, forKey: "v2.totalScansCount") }
    }
    @Published var playerName: String {
        didSet { UserDefaults.standard.set(playerName, forKey: "v2.playerName") }
    }
    @Published var bestStreak: Int {
        didSet { UserDefaults.standard.set(bestStreak, forKey: "v2.bestStreak") }
    }
    
    @Published var achievements: [Achievement] = Achievement.all
    
    init() {
        let ud = UserDefaults.standard
        // All keys prefixed v2. to start fresh, avoiding stale data from old versions
        totalPlastic         = ud.double(forKey: "v2.totalPlastic")
        streakDays           = ud.integer(forKey: "v2.streakDays")
        lastActiveDateString = ud.string(forKey: "v2.lastActiveDate") ?? ""
        weeklyScans          = (ud.array(forKey: "v2.weeklyScans") as? [Double])
        ?? Array(repeating: 0, count: 7)
        flashcardsLearned    = ud.integer(forKey: "v2.flashcardsLearned")
        gamesPlayed          = ud.integer(forKey: "v2.gamesPlayed")
        perfectGames         = ud.integer(forKey: "v2.perfectGames")
        achievementFlags     = (ud.dictionary(forKey: "v2.achievementFlags") as? [String: Bool]) ?? [:]
        oceanHealthRaw       = ud.object(forKey: "v2.oceanHealth") != nil
        ? ud.double(forKey: "v2.oceanHealth")
        : EcoConfiguration.initialOceanHealth
        hasSeenIntro         = ud.bool(forKey: "v2.hasSeenIntro")
        hasSeenOutro         = ud.bool(forKey: "v2.hasSeenOutro")
        dailyGoalProgress    = ud.double(forKey: "v2.dailyGoalProgress")
        lastDailyResetString = ud.string(forKey: "v2.lastDailyReset") ?? ""
        weeklyActiveDays     = (ud.array(forKey: "v2.weeklyActiveDays") as? [String]) ?? []
        totalScansCount      = ud.integer(forKey: "v2.totalScansCount")
        playerName           = ud.string(forKey: "v2.playerName") ?? ""
        bestStreak           = ud.integer(forKey: "v2.bestStreak")
        
        
        if let data = ud.data(forKey: "v2.lifetimeScans"),
           let decoded = try? JSONDecoder().decode([String: Double].self, from: data) {
            lifetimeScans = decoded
        } else {
            lifetimeScans = [:]
        }
        
        for i in achievements.indices {
            if achievementFlags[achievements[i].key] == true {
                achievements[i].unlocked = true
            }
        }
        
        resetDailyGoalIfNeeded()
        pruneWeeklyActiveDays()
    }
    
    var dailyGoalTarget: Double  { EcoConfiguration.dailyGoalTarget }
    var dailyGoalPercent: Double { min(dailyGoalProgress / dailyGoalTarget, 1.0) }
    var dailyGoalMet: Bool       { dailyGoalProgress >= dailyGoalTarget }
    
    func resetDailyGoalIfNeeded() {
        let todayStr = Self.dateString(Date())
        if lastDailyResetString != todayStr {
            dailyGoalProgress    = 0
            lastDailyResetString = todayStr
        }
    }
    
    var oceanHealth: Double { max(0, min(1, oceanHealthRaw)) }
    var oceanPhase: OceanPhase { EcoConfiguration.oceanPhase(for: oceanHealth) }
    
    func improveOceanHealth(by delta: Double) {
        oceanHealthRaw = min(1.0, oceanHealthRaw + delta)
        SoundManager.shared.updateAmbientForHealth(oceanHealthRaw)
    }
    func damageOceanHealth(by delta: Double) {
        oceanHealthRaw = max(0.0, oceanHealthRaw - delta)
        SoundManager.shared.updateAmbientForHealth(oceanHealthRaw)
    }
    
    var co2SavedKg: Double        { totalPlastic * 0.0000215 }
    var bottlesSaved: Int         { Int(totalPlastic / 20.0) }
    var strawsSaved: Int          { Int(totalPlastic / 0.5)  }
    var bagsSaved: Int            { Int(totalPlastic / 8.0)  }
    var oceanAreaCleaned: Double  { totalPlastic * 0.00012   }
    
    var oceanLevel: Int           { max(1, min(50, Int(totalPlastic / 25.0) + 1)) }
    var levelProgress: Double     { (totalPlastic.truncatingRemainder(dividingBy: 25.0)) / 25.0 }
    var levelTitle: String {
        switch oceanLevel {
        case 1...3:   return "Beach Cleaner"
        case 4...7:   return "Shore Guardian"
        case 8...12:  return "Reef Protector"
        case 13...18: return "Ocean Steward"
        case 19...25: return "Sea Champion"
        case 26...35: return "Marine Hero"
        case 36...49: return "Ocean Legend"
        default:      return "Ocean Master"
        }
    }
    
    func lifetimeChartData(months: Int = 6) -> [(label: String, grams: Double)] {
        let calendar = Calendar.current
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM"
        let labelFormatter = DateFormatter()
        labelFormatter.dateFormat = "MMM"
        var result: [(label: String, grams: Double)] = []
        for offset in stride(from: months - 1, through: 0, by: -1) {
            guard let date = calendar.date(byAdding: .month, value: -offset, to: Date()) else { continue }
            let key = formatter.string(from: date)
            let label = labelFormatter.string(from: date)
            result.append((label: label, grams: lifetimeScans[key] ?? 0))
        }
        return result
    }
    
    var weeklyConsistencyScore: Int {
        let calendar = Calendar.current
        let today    = Date()
        return (0..<7).filter { offset in
            guard let day = calendar.date(byAdding: .day, value: -offset, to: today) else { return false }
            return weeklyActiveDays.contains(Self.dateString(day))
        }.count
    }
    
    var behavioralSummary: String { EcoConfiguration.streakMessage(for: streakDays) }
    var motivationalQuote: String { EcoConfiguration.dailyQuote() }
    
    private func pruneWeeklyActiveDays() {
        let calendar = Calendar.current
        let cutoff   = calendar.date(byAdding: .day, value: -7, to: Date()) ?? Date()
        weeklyActiveDays = weeklyActiveDays.filter {
            guard let d = Self.dateFromString($0) else { return false }
            return d >= cutoff
        }
    }
    
    private func recordActiveDay() {
        let todayStr = Self.dateString(Date())
        if !weeklyActiveDays.contains(todayStr) {
            weeklyActiveDays.append(todayStr)
            pruneWeeklyActiveDays()
        }
        // Record EVERY scan to lifetime monthly bucket (not just first per day)
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM"
        let monthKey = formatter.string(from: Date())
        lifetimeScans[monthKey, default: 0] += EcoConfiguration.gramsPerScan
    }
    
    func logScan() {
        let grams = EcoConfiguration.gramsPerScan
        totalPlastic      += grams
        dailyGoalProgress += grams
        totalScansCount   += 1
        let weekday = Calendar.current.component(.weekday, from: Date()) - 1
        weeklyScans[weekday] += grams
        improveOceanHealth(by: EcoConfiguration.healthGainPerScan)
        recordActiveDay()
    }
    
    @discardableResult
    func handleStreak() -> Bool {
        let todayStr = Self.dateString(Date())
        guard lastActiveDateString != todayStr else { return false }
        
        if lastActiveDateString.isEmpty {
            streakDays = 1
        } else if let last = Self.dateFromString(lastActiveDateString) {
            let diff = Calendar.current.dateComponents([.day], from: last, to: Date()).day ?? 0
            if diff == 1 {
                streakDays += 1   
            } else if diff > 1 {
                streakDays = 1   
            }
        } else {
            streakDays = 1
        }
        lastActiveDateString = todayStr
        if streakDays > bestStreak { bestStreak = streakDays }
        return true
    }
    
    @discardableResult
    func checkAchievements() -> String? {
        for i in achievements.indices {
            guard !achievements[i].unlocked else { continue }
            let shouldUnlock: Bool
            switch achievements[i].trigger {
            case .firstScan:   shouldUnlock = totalScansCount   >= 1
            case .scans5:      shouldUnlock = totalScansCount   >= 5
            case .streak3:     shouldUnlock = streakDays        >= EcoConfiguration.thresholdStreak3
            case .streak7:     shouldUnlock = streakDays        >= EcoConfiguration.thresholdStreak7
            case .plastic50:   shouldUnlock = totalPlastic      >= EcoConfiguration.thresholdPlastic50
            case .flashcards6: shouldUnlock = flashcardsLearned >= EcoConfiguration.thresholdFlashcards
            case .playGame:    shouldUnlock = gamesPlayed       >= 1
            case .perfectGame: shouldUnlock = perfectGames      >= 1
            case .dailyGoal:   shouldUnlock = dailyGoalMet
            case .oceanHero:   shouldUnlock = oceanHealth       >= EcoConfiguration.thresholdOceanHero
            }
            if shouldUnlock {
                achievements[i].unlocked              = true
                achievementFlags[achievements[i].key] = true
                SoundManager.shared.playAchievement()
                return achievements[i].title
            }
        }
        return nil
    }
    
    static func dateString(_ date: Date) -> String {
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"
        return f.string(from: date)
    }
    static func dateFromString(_ str: String) -> Date? {
        guard !str.isEmpty else { return nil }
        let f = DateFormatter(); f.dateFormat = "yyyy-MM-dd"
        return f.date(from: str)
    }
}
