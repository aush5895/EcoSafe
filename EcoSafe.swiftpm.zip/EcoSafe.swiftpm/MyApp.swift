import SwiftUI
import UIKit

@main
struct EcoSafeApp: App {
    @Environment(\.scenePhase) var scenePhase
    var body: some Scene {
        WindowGroup {
            ContentView()
                .onChange(of: scenePhase) { _, phase in
                    switch phase {
                    case .background, .inactive: SoundManager.shared.handleAppBackground()
                    case .active:               SoundManager.shared.handleAppForeground()
                    @unknown default:            break
                    }
                }
        }
    }
}

struct OceanTheme {
    static let deepBlue = Color(red: 0.04, green: 0.10, blue: 0.26)
    static let midBlue  = Color(red: 0.06, green: 0.22, blue: 0.44)
    static let teal     = Color(red: 0.00, green: 0.72, blue: 0.80)
    static let coral    = Color(red: 1.00, green: 0.45, blue: 0.35)
    static let seaGreen = Color(red: 0.13, green: 0.72, blue: 0.52)
    static let gold     = Color(red: 1.00, green: 0.82, blue: 0.22)
    
    static func gradient(health: Double) -> LinearGradient {
        switch EcoConfiguration.oceanPhase(for: health) {
        case .polluted:
            return LinearGradient(colors: [Color(red:0.08,green:0.08,blue:0.18),
                                           Color(red:0.10,green:0.14,blue:0.28),
                                           Color(red:0.04,green:0.28,blue:0.36)],
                                  startPoint: .topLeading, endPoint: .bottomTrailing)
        case .stabilizing:
            return LinearGradient(colors: [Color(red:0.04,green:0.10,blue:0.26),
                                           Color(red:0.04,green:0.20,blue:0.40),
                                           teal.opacity(0.42)],
                                  startPoint: .topLeading, endPoint: .bottomTrailing)
        case .recovering:
            return LinearGradient(colors: [Color(red:0.04,green:0.12,blue:0.28),
                                           Color(red:0.04,green:0.26,blue:0.46),
                                           teal.opacity(0.58)],
                                  startPoint: .topLeading, endPoint: .bottomTrailing)
        case .flourishing:
            return LinearGradient(colors: [Color(red:0.03,green:0.14,blue:0.30),
                                           Color(red:0.04,green:0.30,blue:0.50),
                                           teal.opacity(0.72)],
                                  startPoint: .topLeading, endPoint: .bottomTrailing)
        case .thriving:
            return LinearGradient(colors: [Color(red:0.03,green:0.16,blue:0.32),
                                           Color(red:0.04,green:0.34,blue:0.54),
                                           teal.opacity(0.88)],
                                  startPoint: .topLeading, endPoint: .bottomTrailing)
        }
    }
}

enum AchievementTrigger {
    case firstScan, scans5, streak3, streak7, plastic50
    case flashcards6, playGame, perfectGame, dailyGoal, oceanHero
}

struct Achievement: Identifiable {
    let id        = UUID()
    let key:      String
    let emoji:    String
    let title:    String
    let subtitle: String
    let trigger:  AchievementTrigger
    var unlocked: Bool = false
    
    static let all: [Achievement] = [
        Achievement(key:"firstScan",   emoji:"🌱", title:"First Step",    subtitle:"Completed first scan",     trigger:.firstScan),
        Achievement(key:"scans5",      emoji:"♻️", title:"Recycler",       subtitle:"Scanned 5 items",          trigger:.scans5),
        Achievement(key:"streak3",     emoji:"🔥", title:"On a Roll",      subtitle:"3-day streak",             trigger:.streak3),
        Achievement(key:"streak7",     emoji:"💫", title:"Committed",      subtitle:"7-day streak",             trigger:.streak7),
        Achievement(key:"plastic50",   emoji:"🌊", title:"Ocean Friend",   subtitle:"Saved 50g of plastic",     trigger:.plastic50),
        Achievement(key:"flashcards6", emoji:"🎓", title:"Eco Scholar",    subtitle:"Mastered all 12 flashcards",  trigger:.flashcards6),
        Achievement(key:"playGame",    emoji:"🎮", title:"Into the Ocean", subtitle:"Played Ocean Rescue",      trigger:.playGame),
        Achievement(key:"perfectGame", emoji:"💎", title:"Flawless",       subtitle:"Perfect game, no misses",  trigger:.perfectGame),
        Achievement(key:"dailyGoal",   emoji:"🎯", title:"Daily Guardian", subtitle:"Hit daily plastic goal",   trigger:.dailyGoal),
        Achievement(key:"oceanHero",   emoji:"🐋", title:"Ocean Hero",     subtitle:"Ocean health at 85%+",     trigger:.oceanHero),
    ]
}

struct ContentView: View {
    @StateObject private var state = AppState()
    
    @State private var appStage: AppStage = .loading
    @State private var showLearnCard      = false
    @State private var showScanView       = false
    @State private var showGameView       = false
    @State private var selectedTab        = 0
    @State private var streakDidIncrease  = false
    @State private var toastText          = ""
    @State private var showToast          = false
    @State private var achievementName    = ""
    @State private var showAchievement    = false
    @State private var showConfetti       = false
    @State private var showDailyComplete  = false
    @State private var showOutro          = false
    @State private var healthBounce       = false
    
    enum AppStage { case loading, intro, main, outro }
    
    var body: some View {
        ZStack {
            switch appStage {
            case .loading:
                SplashLoadingView()
                    .onAppear {
                        DispatchQueue.main.asyncAfter(deadline: .now() + 1.4) {
                            withAnimation(.easeInOut(duration: 0.5)) {
                                // BUG FIX 1: Always go to intro (user's intent),
                                // but still start ambient if returning user
                                if state.hasSeenIntro {
                                    SoundManager.shared.startAmbient()
                                }
                                appStage = .intro
                            }
                        }
                    }
                
            case .intro:
                CinematicIntroView { name in
                    if !name.isEmpty { state.playerName = name }
                    state.hasSeenIntro = true
                    withAnimation(.easeInOut(duration: 0.7)) { appStage = .main }
                    SoundManager.shared.startAmbient()
                }
                .transition(.asymmetric(
                    insertion: .opacity,
                    removal: .move(edge: .leading).combined(with: .opacity)))
                
            case .main:
                mainTabView
                    .transition(.asymmetric(
                        insertion: .move(edge: .trailing).combined(with: .opacity),
                        removal: .opacity))
                
            case .outro:
                MotivationOutroView {
                    state.hasSeenOutro = true
                    // BUG FIX 2: Outro must return to .main, not .intro (your version had .intro)
                    withAnimation(.easeInOut(duration: 0.7)) { appStage = .main }
                }
                .transition(.asymmetric(
                    insertion: .move(edge: .bottom).combined(with: .opacity),
                    removal: .move(edge: .top).combined(with: .opacity)))
            }
        }
        .animation(.easeInOut(duration: 0.5), value: appStage)
      
        .onAppear { }
    }
        var mainTabView: some View {
        ZStack(alignment: .bottom) {
            TabView(selection: $selectedTab) {
                DashboardView(
                    streakDidIncrease: streakDidIncrease,
                    healthBounce:      healthBounce,
                    showScanView:      $showScanView,
                    showLearnCard:     $showLearnCard,
                    showOutro:         $showOutro
                )
                .environmentObject(state)
                .tabItem { Label("Home",   systemImage: "house.fill")          }.tag(0)
                
                ImpactView()
                    .environmentObject(state)
                    .tabItem { Label("Impact", systemImage: "leaf.fill")        }.tag(1)
                
                FlashcardsView(showConfetti: $showConfetti)
                    .environmentObject(state)
                    .tabItem { Label("Learn",  systemImage: "book.fill")        }.tag(2)
                
                AboutView()
                    .environmentObject(state)
                    .tabItem { Label("About",  systemImage: "info.circle.fill") }.tag(3)
            }
            .accentColor(OceanTheme.teal)
            .onChange(of: selectedTab) { _, _ in SoundManager.shared.hapticLight() }
            .onChange(of: showOutro) { _, val in
                if val {
                    withAnimation(.easeInOut(duration: 0.6)) { appStage = .outro }
                    showOutro = false
                }
            }
            
            ImpactToastView(text: toastText, isVisible: $showToast)
                .padding(.bottom, 84).allowsHitTesting(false)
            
            if showAchievement {
                AchievementBannerView(name: achievementName)
                    .transition(.move(edge: .top).combined(with: .opacity))
                    .padding(.top, 10)
                    .frame(maxHeight: .infinity, alignment: .top)
            }
            
            if showDailyComplete {
                DailyGoalCelebrationView { showDailyComplete = false }
                    .transition(.scale.combined(with: .opacity))
            }
            
            if showConfetti { ConfettiView().allowsHitTesting(false) }
        }
        .sheet(isPresented: $showLearnCard) {
            LearnCardView(showLearnCard: $showLearnCard, showScanView: $showScanView)
        }
        .sheet(isPresented: $showScanView) {
            CameraView(onScanComplete: handleScanComplete, onPlayGame: handlePlayGame)
        }
        .sheet(isPresented: $showGameView) {
            OceanRescueGameView().environmentObject(state)
        }
    
        .onChange(of: showGameView) { _, isShowing in
            if !isShowing && state.gamesPlayed >= 1 {
                
                let didIncrease = state.handleStreak()
                streakDidIncrease = didIncrease
                if didIncrease {
                    toastText = "🔥 Day \(state.streakDays) streak! Keep going."
                    showToast = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 2.4) {
                        showToast = false
                        streakDidIncrease = false
                    }
                }
                if let name = state.checkAchievements() { triggerAchievement(name) }
                
                // Show daily goal celebration if just hit
                if state.dailyGoalMet && !showDailyComplete {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                        withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                            showDailyComplete = true
                        }
                    }
                }
                
                // Show motivation outro the first time after a game
                if !state.hasSeenOutro {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                        // Make sure outro returns to .main (fixed above)
                        withAnimation(.easeInOut(duration: 0.6)) { appStage = .outro }
                    }
                }
            }
        }
    }
    
    private func handleScanComplete() {
        state.logScan()
        let didIncrease = state.handleStreak()
        streakDidIncrease = didIncrease
        
        withAnimation(.spring(response: 0.35, dampingFraction: 0.45)) { healthBounce = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.85) { healthBounce = false }
        
        if let name = state.checkAchievements() { triggerAchievement(name) }
        
        if state.dailyGoalMet && !showDailyComplete {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.6) {
                withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                    showDailyComplete = true
                }
            }
        }
        
        toastText = didIncrease
        ? "🔥 Day \(state.streakDays) streak! Keep going."
        : "+\(String(format: "%.1f", EcoConfiguration.gramsPerScan))g saved 🌊"
        showToast = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.4) {
            showToast         = false
            streakDidIncrease = false
        }
    }
    
    private func handlePlayGame() {
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { showGameView = true }
    }
    
    private func triggerAchievement(_ name: String) {
        achievementName = name
        withAnimation(.spring(response: 0.45, dampingFraction: 0.65)) { showAchievement = true }
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) {
            withAnimation { showAchievement = false }
        }
    }
}

struct SplashLoadingView: View {
    @State private var scale:       CGFloat = 0.70
    @State private var opacity:     Double  = 0
    @State private var ringScale:   CGFloat = 0.5
    @State private var ringOpacity: Double  = 0
    @State private var wavePhase:   CGFloat = 0
    
    var body: some View {
        ZStack {
            OceanTheme.gradient(health: 0.42).ignoresSafeArea()
            Circle().stroke(OceanTheme.teal.opacity(0.18), lineWidth: 1)
                .frame(width: 160, height: 160).scaleEffect(ringScale).opacity(ringOpacity)
            Circle().stroke(OceanTheme.teal.opacity(0.10), lineWidth: 1)
                .frame(width: 220, height: 220).scaleEffect(ringScale).opacity(ringOpacity * 0.6)
            VStack(spacing: 16) {
                Image(systemName: "water.waves")
                    .font(.system(size: 54, weight: .light))
                    .foregroundColor(OceanTheme.teal).scaleEffect(scale)
                    .shadow(color: OceanTheme.teal.opacity(0.5), radius: 20)
                VStack(spacing: 5) {
                    Text("EcoSafe")
                        .font(.system(size: 30, weight: .heavy, design: .rounded)).foregroundColor(.white)
                    Text("FOR THE OCEAN")
                        .font(.system(size: 11, weight: .bold))
                        .foregroundColor(OceanTheme.teal.opacity(0.8)).tracking(3)
                }
            }
            .opacity(opacity)
        }
        .onAppear {
            withAnimation(.spring(response: 0.72, dampingFraction: 0.62)) { scale = 1.0; opacity = 1.0 }
            withAnimation(.easeOut(duration: 0.9).delay(0.2)) { ringScale = 1.0; ringOpacity = 1.0 }
        }
    }
}

struct AnimatedOceanBackground: View {
    let health: Double
    @State private var phase: CGFloat = 0
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    
    var body: some View {
        ZStack {
            OceanTheme.gradient(health: health).ignoresSafeArea()
            if !reduceMotion {
                WaveShape(phase: phase, amplitude: 16 + CGFloat(health * 9), frequency: 1.4)
                    .fill(Color.white.opacity(0.05 + health * 0.04)).ignoresSafeArea()
                WaveShape(phase: phase + 1.3, amplitude: 10 + CGFloat(health * 5), frequency: 1.9)
                    .fill(Color.white.opacity(0.03 + health * 0.02)).ignoresSafeArea()
                if health > 0.6 {
                    WaveShape(phase: phase * 0.7 + 0.9, amplitude: 6, frequency: 2.4)
                        .fill(OceanTheme.teal.opacity((health - 0.6) * 0.12)).ignoresSafeArea()
                }
            }
            if health > 0.5 { CoralSilhouette(health: health) }
        }
        .onAppear {
            guard !reduceMotion else { return }
            withAnimation(.linear(duration: EcoConfiguration.animWaveDuration).repeatForever(autoreverses: false)) {
                phase = .pi * 2
            }
        }
    }
}

struct WaveShape: Shape {
    var phase: CGFloat; var amplitude: CGFloat; var frequency: CGFloat
    var animatableData: CGFloat { get { phase } set { phase = newValue } }
    func path(in rect: CGRect) -> Path {
        var path = Path()
        let midY = rect.height * 0.55
        path.move(to: CGPoint(x: 0, y: midY))
        for x in stride(from: 0, through: rect.width, by: 2) {
            path.addLine(to: CGPoint(x: x, y: midY + amplitude * sin(frequency * (.pi*2/rect.width) * x + phase)))
        }
        path.addLine(to: CGPoint(x: rect.width, y: rect.height))
        path.addLine(to: CGPoint(x: 0, y: rect.height))
        path.closeSubpath(); return path
    }
}

struct CoralSilhouette: View {
    let health: Double
    private let heights: [CGFloat] = [22, 36, 28, 44, 20, 38, 26]
    var body: some View {
        VStack {
            Spacer()
            HStack(alignment: .bottom, spacing: 0) {
                ForEach(0..<7) { i in
                    CoralBranch(height: heights[i] * CGFloat(health),
                                color: i % 2 == 0 ? OceanTheme.coral : OceanTheme.seaGreen)
                    Spacer()
                }
            }
            .frame(height: 50).padding(.horizontal, 18)
        }
        .ignoresSafeArea().allowsHitTesting(false)
    }
}

struct CoralBranch: View {
    let height: CGFloat; let color: Color
    var body: some View {
        RoundedRectangle(cornerRadius: 6).fill(color.opacity(0.35))
            .frame(width: 12, height: max(0, height))
    }
}

struct BubbleBackground: View {
    let bubbles: [BubbleData] = (0..<14).map { _ in BubbleData() }
    var body: some View {
        ZStack { ForEach(bubbles) { b in BubbleView(data: b) } }.allowsHitTesting(false)
    }
}

struct BubbleData: Identifiable {
    let id       = UUID()
    let x:        CGFloat = CGFloat.random(in: 0.05...0.95)
    let size:     CGFloat = CGFloat.random(in: 5...18)
    let duration: Double  = Double.random(in: EcoConfiguration.animBubbleMinDuration...EcoConfiguration.animBubbleMaxDuration)
    let delay:    Double  = Double.random(in: 0...4)
    let opacity:  Double  = Double.random(in: 0.06...0.18)
}

struct BubbleView: View {
    let data: BubbleData
    @State private var up = false
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    var body: some View {
        GeometryReader { geo in
            Circle().fill(Color.white.opacity(data.opacity))
                .frame(width: data.size, height: data.size)
                .position(x: geo.size.width * data.x, y: up ? -data.size : geo.size.height + data.size)
                .onAppear {
                    guard !reduceMotion else { return }
                    DispatchQueue.main.asyncAfter(deadline: .now() + data.delay) {
                        withAnimation(.linear(duration: data.duration).repeatForever(autoreverses: false)) { up = true }
                    }
                }
        }
    }
}

struct SwimmingFish: View {
    @State private var x: CGFloat = -80
    let yFraction: CGFloat; let delay: Double; let speed: Double; let size: CGFloat; let emoji: String
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    var body: some View {
        GeometryReader { geo in
            Text(emoji).font(.system(size: size))
                .position(x: x, y: geo.size.height * yFraction)
                .onAppear {
                    guard !reduceMotion else { return }
                    x = -80
                    DispatchQueue.main.asyncAfter(deadline: .now() + delay) {
                        withAnimation(.linear(duration: speed).repeatForever(autoreverses: false)) {
                            x = geo.size.width + 80
                        }
                    }
                }
        }.allowsHitTesting(false)
    }
}

private let confettiColors: [Color] = [OceanTheme.teal, OceanTheme.seaGreen, OceanTheme.gold, OceanTheme.coral, .white]

struct ConfettiPiece: Identifiable {
    let id       = UUID()
    let x:        CGFloat = CGFloat.random(in: 0...1)
    let color:    Color   = confettiColors[Int.random(in: 0..<confettiColors.count)]
    let size:     CGFloat = CGFloat.random(in: 6...13)
    let duration: Double  = Double.random(in: 1.6...3.2)
    let delay:    Double  = Double.random(in: 0...0.9)
    let rotation: Double  = Double.random(in: 0...360)
}

struct ConfettiView: View {
    let pieces: [ConfettiPiece] = (0..<55).map { _ in ConfettiPiece() }
    var body: some View { ZStack { ForEach(pieces) { p in ConfettiFall(piece: p) } }.ignoresSafeArea() }
}

struct ConfettiFall: View {
    let piece: ConfettiPiece
    @State private var y: CGFloat = -20
    @State private var opacity: Double = 1
    var body: some View {
        GeometryReader { geo in
            RoundedRectangle(cornerRadius: 2).fill(piece.color)
                .frame(width: piece.size, height: piece.size * 0.5)
                .rotationEffect(.degrees(piece.rotation))
                .position(x: geo.size.width * piece.x, y: y).opacity(opacity)
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + piece.delay) {
                        withAnimation(.easeIn(duration: piece.duration)) { y = geo.size.height + 40; opacity = 0 }
                    }
                }
        }
    }
}

struct ImpactToastView: View {
    let text: String; @Binding var isVisible: Bool
    var body: some View {
        VStack {
            Spacer()
            if isVisible {
                HStack(spacing: 8) {
                    Image(systemName: "checkmark.circle.fill").foregroundColor(OceanTheme.teal)
                    Text(text).font(.system(size: 14, weight: .semibold)).foregroundColor(.white)
                }
                .padding(.horizontal, 18).padding(.vertical, 11)
                .background(Capsule().fill(Color(red:0.05,green:0.16,blue:0.30))
                    .shadow(color: OceanTheme.teal.opacity(0.4), radius: 10, x: 0, y: 4))
                .overlay(Capsule().stroke(OceanTheme.teal.opacity(0.38), lineWidth: 1))
                .transition(.move(edge: .bottom).combined(with: .opacity))
                .padding(.bottom, 18)
            }
        }
        .animation(.spring(response: 0.45, dampingFraction: 0.72), value: isVisible)
    }
}

struct AchievementBannerView: View {
    let name: String
    @State private var shown   = false
    @State private var shimmer: CGFloat = -1.0
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "rosette").font(.system(size: 22, weight: .bold)).foregroundColor(OceanTheme.gold)
            VStack(alignment: .leading, spacing: 2) {
                Text("Achievement Unlocked")
                    .font(.system(size: 10, weight: .bold)).foregroundColor(OceanTheme.teal).tracking(0.5)
                Text(name).font(.system(size: 15, weight: .heavy, design: .rounded)).foregroundColor(.white)
            }
            Spacer()
            Image(systemName: "sparkles").foregroundColor(OceanTheme.gold.opacity(0.8))
        }
        .padding(.horizontal, 16).padding(.vertical, 11)
        .background(ZStack {
            RoundedRectangle(cornerRadius: 16).fill(Color(red:0.05,green:0.14,blue:0.28))
                .shadow(color: OceanTheme.teal.opacity(0.4), radius: 14)
            RoundedRectangle(cornerRadius: 16)
                .fill(LinearGradient(colors: [.clear, .white.opacity(0.08), .clear],
                                     startPoint: UnitPoint(x: shimmer, y: 0),
                                     endPoint: UnitPoint(x: shimmer + 0.4, y: 1)))
        })
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(OceanTheme.teal.opacity(0.4), lineWidth: 1))
        .padding(.horizontal, 16)
        .scaleEffect(shown ? 1 : 0.88).opacity(shown ? 1 : 0)
        .onAppear {
            withAnimation(.spring(response: 0.4, dampingFraction: 0.62)) { shown = true }
            withAnimation(.easeInOut(duration: 1.2).delay(0.5)) { shimmer = 1.4 }
        }
        .accessibilityLabel("Achievement unlocked: \(name)")
    }
}

struct DailyGoalCelebrationView: View {
    let onDismiss: () -> Void
    @State private var scale:      CGFloat = 0.7
    @State private var emojiScale: CGFloat = 0.3
    @State private var glowRadius: CGFloat = 0
    var body: some View {
        ZStack {
            Color.black.opacity(0.55).ignoresSafeArea().onTapGesture { onDismiss() }
            VStack(spacing: 18) {
                Text("🎯").font(.system(size: 64)).scaleEffect(emojiScale)
                    .shadow(color: OceanTheme.teal.opacity(0.5), radius: glowRadius)
                Text("Daily Goal Reached!")
                    .font(.system(size: 22, weight: .heavy, design: .rounded)).foregroundColor(.white)
                Text("You've intercepted your daily target.\nThe ocean remembers every action.")
                    .font(.system(size: 14)).foregroundColor(.white.opacity(0.7)).multilineTextAlignment(.center)
                Button(action: onDismiss) {
                    Text("Keep Going 🌊")
                        .font(.system(size: 16, weight: .bold)).foregroundColor(.white)
                        .frame(width: 200, height: 48).background(OceanTheme.teal).cornerRadius(14)
                }
            }
            .padding(28)
            .background(RoundedRectangle(cornerRadius: 24).fill(OceanTheme.midBlue))
            .padding(.horizontal, 34).scaleEffect(scale)
        }
        .onAppear {
            withAnimation(.spring(response: 0.5, dampingFraction: 0.6)) { scale = 1.0 }
            withAnimation(.spring(response: 0.4, dampingFraction: 0.5).delay(0.15)) { emojiScale = 1.0 }
            withAnimation(.easeInOut(duration: 1.2).delay(0.3).repeatForever(autoreverses: true)) { glowRadius = 22 }
        }
    }
}

struct DashboardView: View {
    @EnvironmentObject var state: AppState
    let streakDidIncrease: Bool
    let healthBounce: Bool
    @Binding var showScanView:  Bool
    @Binding var showLearnCard: Bool
    @Binding var showOutro:     Bool
    
    @State private var headerIn     = false
    @State private var cardsIn      = false
    @State private var scanPulse    = false
    @State private var streakBounce = false
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    
    private var phase: OceanPhase { state.oceanPhase }
    
    var greeting: String {
        let h = Calendar.current.component(.hour, from: Date())
        let timeGreet = h < 12 ? "Good morning" : h < 17 ? "Good afternoon" : "Good evening"
        let name = state.playerName.trimmingCharacters(in: .whitespaces)
        return name.isEmpty ? timeGreet : "\(timeGreet), \(name)"
    }
    
    @ViewBuilder
    var fishLayer: some View {
        if state.oceanHealth > 0.25 { SwimmingFish(yFraction: 0.48, delay: 1.5, speed: 16, size: 16, emoji: "🐟") }
        if state.oceanHealth > 0.55 { SwimmingFish(yFraction: 0.65, delay: 6,   speed: 12, size: 14, emoji: "🐠") }
        if state.oceanHealth > 0.80 { SwimmingFish(yFraction: 0.32, delay: 11,  speed: 19, size: 20, emoji: "🐡") }
    }
    
    @ViewBuilder
    var headerSection: some View {
        VStack(spacing: 6) {
            Text(greeting)
                .font(.system(size: 14, weight: .medium)).foregroundColor(.white.opacity(0.58))
            Text("EcoSafe")
                .font(.system(size: 34, weight: .heavy, design: .rounded)).foregroundColor(.white)
            HStack(spacing: 8) {
                HStack(spacing: 5) {
                    Circle().fill(phase.color).frame(width: 7, height: 7)
                    Text("Ocean: \(phase.label)")
                        .font(.system(size: 10, weight: .bold)).foregroundColor(phase.color).tracking(0.5)
                }
                .padding(.horizontal, 11).padding(.vertical, 5)
                .background(phase.color.opacity(0.14)).cornerRadius(9)
                .overlay(RoundedRectangle(cornerRadius: 9).stroke(phase.color.opacity(0.3), lineWidth: 1))
                
                // Ocean Level badge
                HStack(spacing: 4) {
                    Image(systemName: "star.fill").font(.system(size: 8)).foregroundColor(OceanTheme.gold)
                    Text("Lv.\(state.oceanLevel)").font(.system(size: 10, weight: .heavy)).foregroundColor(OceanTheme.gold)
                }
                .padding(.horizontal, 10).padding(.vertical, 5)
                .background(OceanTheme.gold.opacity(0.14)).cornerRadius(9)
                .overlay(RoundedRectangle(cornerRadius: 9).stroke(OceanTheme.gold.opacity(0.35), lineWidth: 1))
                .accessibilityLabel("Level \(state.oceanLevel) \(state.levelTitle)")
            }
            // Level title + XP bar
            OceanLevelBar(level: state.oceanLevel, title: state.levelTitle, progress: state.levelProgress)
                .padding(.horizontal, 28)
        }
        .padding(.top, 60)
        .opacity(headerIn ? 1 : 0)
        .offset(y: headerIn ? 0 : -20)
    }
    
    @ViewBuilder
    var ringSection: some View {
        DailyProgressRing(
            dailyGoalProgress: state.dailyGoalProgress,
            dailyGoalTarget:   state.dailyGoalTarget,
            dailyGoalPercent:  state.dailyGoalPercent,
            dailyGoalMet:      state.dailyGoalMet
        )
        .opacity(headerIn ? 1 : 0)
        .scaleEffect(headerIn ? 1.0 : 0.82)
        .scaleEffect(healthBounce ? 1.05 : 1.0)
        .animation(.spring(response: 0.32, dampingFraction: 0.5), value: healthBounce)
    }
    
    @ViewBuilder
    var statsSection: some View {
        OceanHealthBar(health: state.oceanHealth)
            .padding(.horizontal, 20).opacity(cardsIn ? 1 : 0)
        
        HStack(spacing: 12) {
            StreakPill(days: state.streakDays, bounce: streakBounce)
            StatPill(
                icon: "trophy.fill",
                value: "\(state.bestStreak)d",
                label: "Best Streak",
                color: OceanTheme.gold
            )
        }
        .padding(.horizontal, 20)
        .opacity(cardsIn ? 1 : 0)
        .offset(y: cardsIn ? 0 : 20)
        
        HStack(spacing: 12) {
            StatPill(
                icon: "drop.fill",
                value: String(format: "%.0fg", state.totalPlastic),
                label: "Plastic Saved",
                color: OceanTheme.teal
            )
            StatPill(
                icon: "bag.fill",
                value: "\(state.bagsSaved)",
                label: "Bags Prevented",
                color: OceanTheme.seaGreen
            )
        }
        .padding(.horizontal, 20)
        .opacity(cardsIn ? 1 : 0)
        .offset(y: cardsIn ? 0 : 20)
        
        RetentionNudgeCard(state: state)
            .padding(.horizontal, 20).opacity(cardsIn ? 1 : 0)
    }
    
    @ViewBuilder
    var chartsSection: some View {
        WeeklyChart()
            .padding(.horizontal, 20)
            .opacity(cardsIn ? 1 : 0)
            .offset(y: cardsIn ? 0 : 20)
        
        AchievementsRow(achievements: state.achievements)
            .padding(.horizontal, 20).opacity(cardsIn ? 1 : 0)
    }
    
    @ViewBuilder
    var ctaSection: some View {
        ScanButton(
            phase: phase,
            scanPulse: scanPulse,
            cardsIn: cardsIn,
            onTap: { SoundManager.shared.playTap(); showLearnCard = true }
        )
        
        if state.totalScansCount > 0 {
            OceanStoryButton(cardsIn: cardsIn, onTap: { SoundManager.shared.playTap(); showOutro = true })
        }
    }
    
    var body: some View {
        ZStack {
            AnimatedOceanBackground(health: state.oceanHealth)
            BubbleBackground()
            fishLayer
            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    headerSection
                    ringSection
                    statsSection
                    chartsSection
                    ctaSection
                    Spacer(minLength: 44)
                }
            }
        }
        .onAppear {
            let m = reduceMotion
            withAnimation(.spring(response: 0.65, dampingFraction: 0.78)
                .delay(m ? 0 : EcoConfiguration.animHeaderDelay)) { headerIn = true }
            withAnimation(.spring(response: 0.65, dampingFraction: 0.78)
                .delay(m ? 0 : EcoConfiguration.animCardsDelay)) { cardsIn = true }
            if !m {
                withAnimation(.easeInOut(duration: 2.0).repeatForever(autoreverses: true).delay(0.7)) {
                    scanPulse = true
                }
            }
        }
        .onChange(of: streakDidIncrease) { _, val in
            guard val else { return }
            withAnimation(.spring(response: 0.28, dampingFraction: 0.4)) { streakBounce = true }
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { streakBounce = false }
        }
    }
}
struct DailyProgressRing: View {
    let dailyGoalProgress: Double
    let dailyGoalTarget:   Double
    let dailyGoalPercent:  Double
    let dailyGoalMet:      Bool
    
    @State private var animPct: Double = 0
    
    var body: some View {
        ZStack {
            Circle().stroke(Color.white.opacity(0.12), lineWidth: 14)
            Circle()
                .trim(from: 0, to: CGFloat(animPct))
                .stroke(
                    AngularGradient(
                        colors: [OceanTheme.teal, OceanTheme.seaGreen, OceanTheme.teal],
                        center: .center),
                    style: StrokeStyle(lineWidth: 14, lineCap: .round)
                )
                .rotationEffect(.degrees(-90))
                .animation(.easeOut(duration: 0.55), value: animPct)
            
            VStack(spacing: 3) {
                Text(dailyGoalMet ? "✓" : "\(Int(dailyGoalPercent * 100))%")
                    .font(.system(size: 36, weight: .heavy, design: .rounded))
                    .foregroundColor(dailyGoalMet ? OceanTheme.seaGreen : .white)
                    .contentTransition(.numericText())
                    .animation(.spring(), value: dailyGoalProgress)
                Text("Daily Goal")
                    .font(.system(size: 10, weight: .semibold)).foregroundColor(.white.opacity(0.6))
                Text(String(format: "%.1f / %.0fg", dailyGoalProgress, dailyGoalTarget))
                    .font(.system(size: 11)).foregroundColor(OceanTheme.teal)
                    .animation(.spring(), value: dailyGoalProgress)
            }
        }
        .frame(width: 170, height: 170)
        .onAppear {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.45) {
                withAnimation(.easeOut(duration: 1.1)) { animPct = dailyGoalPercent }
            }
        }
        .onChange(of: dailyGoalPercent) { _, newVal in
            withAnimation(.easeOut(duration: 0.55)) { animPct = newVal }
        }
        .accessibilityLabel("Daily goal \(Int(dailyGoalPercent * 100))% of \(Int(dailyGoalTarget)) grams")
    }
}

struct OceanHealthBar: View {
    let health: Double
    @State private var shown = false
    private var phase: OceanPhase { EcoConfiguration.oceanPhase(for: health) }
    var body: some View {
        VStack(alignment: .leading, spacing: 7) {
            HStack {
                Label("Ocean Health", systemImage: "water.waves")
                    .font(.system(size: 12, weight: .semibold)).foregroundColor(.white.opacity(0.65))
                Spacer()
                Text(phase.label).font(.system(size: 11, weight: .bold)).foregroundColor(phase.color)
            }
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 4).fill(Color.white.opacity(0.08)).frame(height: 8)
                    RoundedRectangle(cornerRadius: 4).fill(phase.color)
                        .frame(width: shown ? max(8, g.size.width * CGFloat(health)) : 8, height: 8)
                        .animation(.spring(response: 1.0, dampingFraction: 0.72).delay(0.3), value: shown)
                        .animation(.easeOut(duration: 0.55), value: health)
                }
            }.frame(height: 8)
            Text(phase.narrativeBody)
                .font(.system(size: 10)).foregroundColor(.white.opacity(0.45))
                .animation(.easeInOut(duration: 0.6), value: phase)
        }
        .padding(12).background(Color.white.opacity(0.07)).cornerRadius(12)
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(phase.color.opacity(0.18), lineWidth: 1))
        .animation(.easeInOut(duration: 0.5), value: phase)
        .onAppear { shown = true }
        .accessibilityLabel("Ocean health \(phase.label) \(Int(health*100))%")
    }
}

struct RetentionNudgeCard: View {
    let state: AppState
    @State private var shown = false
    var body: some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 5) {
                Text(state.behavioralSummary)
                    .font(.system(size: 13, weight: .bold)).foregroundColor(.white)
                Text(state.motivationalQuote)
                    .font(.system(size: 11)).foregroundColor(.white.opacity(0.62))
                    .fixedSize(horizontal: false, vertical: true)
                HStack(spacing: 4) {
                    ForEach(0..<7) { i in
                        RoundedRectangle(cornerRadius: 3)
                            .fill(i < state.weeklyConsistencyScore ? OceanTheme.teal : Color.white.opacity(0.12))
                            .frame(width: 18, height: 6)
                    }
                    Text("\(state.weeklyConsistencyScore)/7 days")
                        .font(.system(size: 9, weight: .semibold))
                        .foregroundColor(.white.opacity(0.45)).padding(.leading, 4)
                }
                .padding(.top, 2)
            }
            Spacer()
            Image(systemName: "chart.line.uptrend.xyaxis")
                .font(.system(size: 22)).foregroundColor(OceanTheme.teal.opacity(0.7))
        }
        .padding(13).background(Color.white.opacity(0.07)).cornerRadius(13)
        .overlay(RoundedRectangle(cornerRadius: 13).stroke(OceanTheme.teal.opacity(0.18), lineWidth: 1))
        .opacity(shown ? 1 : 0).offset(y: shown ? 0 : 10)
        .onAppear { withAnimation(.spring(response: 0.5, dampingFraction: 0.8).delay(0.5)) { shown = true } }
    }
}

struct WeeklyChart: View {
    // Read directly from AppState so @Published changes trigger redraws
    @EnvironmentObject var state: AppState
    let days = ["S","M","T","W","T","F","S"]
    @State private var animHeights: [CGFloat] = Array(repeating: 4, count: 7)
    var todayIndex: Int { Calendar.current.component(.weekday, from: Date()) - 1 }
    
    private func targetHeights(for scans: [Double]) -> [CGFloat] {
        let maxVal = max(scans.max() ?? 1, 1)
        return scans.map { max(4, CGFloat($0 / maxVal) * 50) }
    }
    
    var body: some View {
        let scans = state.weeklyScans
        return VStack(alignment: .leading, spacing: 10) {
            Text("This Week").font(.system(size: 12, weight: .bold)).foregroundColor(.white.opacity(0.6))
            HStack(alignment: .bottom, spacing: 6) {
                ForEach(0..<7) { i in
                    VStack(spacing: 3) {
                        if scans[i] > 0 {
                            Text(String(format: "%.0f", scans[i]))
                                .font(.system(size: 8, weight: .bold)).foregroundColor(OceanTheme.teal)
                        }
                        RoundedRectangle(cornerRadius: 4)
                            .fill(i == todayIndex ? OceanTheme.teal : Color.white.opacity(0.18))
                            .frame(height: animHeights[i])
                        Text(days[i])
                            .font(.system(size: 9, weight: i == todayIndex ? .bold : .regular))
                            .foregroundColor(i == todayIndex ? OceanTheme.teal : .white.opacity(0.4))
                    }.frame(maxWidth: .infinity)
                }
            }.frame(height: 68)
        }
        .padding(13).background(Color.white.opacity(0.07)).cornerRadius(13)
        .overlay(RoundedRectangle(cornerRadius: 13).stroke(Color.white.opacity(0.10), lineWidth: 1))
        .onAppear {
            let targets = targetHeights(for: scans)
            for i in 0..<7 {
                withAnimation(.spring(response: 0.55, dampingFraction: 0.68)
                    .delay(Double(i) * 0.06)) {
                        animHeights[i] = targets[i]
                    }
            }
        }
        .onChange(of: state.weeklyScans) { _, newScans in
            let targets = targetHeights(for: newScans)
            withAnimation(.spring(response: 0.55, dampingFraction: 0.68)) {
                for i in 0..<7 { animHeights[i] = targets[i] }
            }
        }
    }
}

struct AchievementsRow: View {
    let achievements: [Achievement]
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            HStack {
                Text("Achievements").font(.system(size: 12, weight: .bold)).foregroundColor(.white.opacity(0.6))
                Spacer()
                let n = achievements.filter { $0.unlocked }.count
                Text("\(n)/\(achievements.count)").font(.system(size: 11)).foregroundColor(OceanTheme.teal)
            }
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 10) {
                    ForEach(achievements) { a in
                        VStack(spacing: 5) {
                            ZStack {
                                Circle()
                                    .fill(a.unlocked ? OceanTheme.teal.opacity(0.22) : Color.white.opacity(0.06))
                                    .frame(width: 48, height: 48)
                                Text(a.emoji).font(.system(size: 22)).opacity(a.unlocked ? 1 : 0.22)
                                if !a.unlocked {
                                    Image(systemName: "lock.fill")
                                        .font(.system(size: 8)).foregroundColor(.white.opacity(0.3))
                                        .offset(x: 14, y: 14)
                                }
                            }
                            Text(a.title)
                                .font(.system(size: 8, weight: .semibold))
                                .foregroundColor(a.unlocked ? .white : .white.opacity(0.28)).lineLimit(1)
                        }
                        .frame(width: 60)
                        .accessibilityLabel("\(a.title): \(a.unlocked ? "unlocked" : "locked")")
                    }
                }
            }
        }
        .padding(13).background(Color.white.opacity(0.07)).cornerRadius(13)
        .overlay(RoundedRectangle(cornerRadius: 13).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }
}

struct StreakPill: View {
    let days: Int; let bounce: Bool
    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: "flame.fill").foregroundColor(.orange).font(.system(size: 18))
            VStack(alignment: .leading, spacing: 1) {
                Text("\(days) Day\(days == 1 ? "" : "s")")
                    .font(.system(size: 16, weight: .heavy, design: .rounded)).foregroundColor(.white)
                    .contentTransition(.numericText())
                Text("Streak").font(.system(size: 10)).foregroundColor(.white.opacity(0.55))
            }
            Spacer()
        }
        .padding(13).background(Color.white.opacity(0.09)).cornerRadius(13)
        .overlay(RoundedRectangle(cornerRadius: 13).stroke(Color.white.opacity(0.12), lineWidth: 1))
        .scaleEffect(bounce ? 1.10 : 1.0)
        .animation(.spring(response: 0.3, dampingFraction: 0.44), value: bounce)
        .accessibilityLabel("\(days)-day streak")
    }
}

struct StatPill: View {
    let icon: String; let value: String; let label: String; let color: Color
    var body: some View {
        HStack(spacing: 9) {
            Image(systemName: icon).font(.system(size: 17, weight: .bold)).foregroundColor(color)
            VStack(alignment: .leading, spacing: 1) {
                Text(value).font(.system(size: 16, weight: .heavy, design: .rounded)).foregroundColor(.white)
                    .contentTransition(.numericText())
                Text(label).font(.system(size: 10)).foregroundColor(.white.opacity(0.55))
            }
            Spacer()
        }
        .padding(13).background(Color.white.opacity(0.09)).cornerRadius(13)
        .overlay(RoundedRectangle(cornerRadius: 13).stroke(Color.white.opacity(0.12), lineWidth: 1))
    }
}

struct OceanLevelBar: View {
    let level: Int
    let title: String
    let progress: Double
    @State private var shown: CGFloat = 0
    
    var body: some View {
        VStack(spacing: 5) {
            HStack {
                HStack(spacing: 4) {
                    Image(systemName: "star.fill").font(.system(size: 9)).foregroundColor(OceanTheme.gold)
                    Text(title).font(.system(size: 11, weight: .bold)).foregroundColor(OceanTheme.gold)
                }
                Spacer()
                Text("Level \(level)").font(.system(size: 10, weight: .semibold)).foregroundColor(.white.opacity(0.5))
                Text("→").font(.system(size: 9)).foregroundColor(.white.opacity(0.3))
                Text("Level \(level + 1)").font(.system(size: 10)).foregroundColor(.white.opacity(0.35))
            }
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 4).fill(Color.white.opacity(0.08)).frame(height: 6)
                    RoundedRectangle(cornerRadius: 4)
                        .fill(LinearGradient(
                            colors: [OceanTheme.gold, OceanTheme.gold.opacity(0.7)],
                            startPoint: .leading, endPoint: .trailing))
                        .frame(width: shown * g.size.width, height: 6)
                        .animation(.easeOut(duration: 1.1).delay(0.6), value: shown)
                }
            }.frame(height: 6)
        }
        .onAppear {
            shown = CGFloat(progress)
        }
        .onChange(of: progress) { _, newVal in
            withAnimation(.easeOut(duration: 0.55)) { shown = CGFloat(newVal) }
        }
        .accessibilityLabel("Level \(level) \(title). \(Int(progress * 100))% to next level.")
    }
}

struct ScanButton: View {
    let phase: OceanPhase
    let scanPulse: Bool
    let cardsIn: Bool
    let onTap: () -> Void
    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 10) {
                Image(systemName: "camera.viewfinder")
                    .font(.system(size: 20, weight: .bold))
                Text("Scan Packaging")
                    .font(.system(size: 17, weight: .bold, design: .rounded))
            }
            .foregroundColor(.white)
            .frame(maxWidth: .infinity).frame(height: 56)
            .background(
                LinearGradient(
                    colors: [OceanTheme.teal, OceanTheme.seaGreen],
                    startPoint: .leading, endPoint: .trailing)
            )
            .cornerRadius(16)
            .shadow(color: OceanTheme.teal.opacity(0.50 * phase.uiAccentOpacity), radius: 14, x: 0, y: 6)
            .scaleEffect(scanPulse ? 1.018 : 1.0)
            .overlay(RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.15), lineWidth: 1))
        }
        .padding(.horizontal, 20)
        .opacity(cardsIn ? 1 : 0)
        .accessibilityLabel("Scan packaging to log plastic saved")
    }
}

struct OceanStoryButton: View {
    let cardsIn: Bool
    let onTap: () -> Void
    var body: some View {
        Button(action: onTap) {
            HStack(spacing: 8) {
                Image(systemName: "sparkles").font(.system(size: 14))
                Text("Your Ocean Story")
                    .font(.system(size: 14, weight: .semibold))
            }
            .foregroundColor(OceanTheme.gold)
            .frame(maxWidth: .infinity).frame(height: 44)
            .background(OceanTheme.gold.opacity(0.12))
            .cornerRadius(13)
            .overlay(
                RoundedRectangle(cornerRadius: 13)
                    .stroke(OceanTheme.gold.opacity(0.35), lineWidth: 1)
            )
        }
        .padding(.horizontal, 20)
        .opacity(cardsIn ? 1 : 0)
        .accessibilityLabel("View your motivating ocean story")
    }
}

struct ImpactView: View {
    @EnvironmentObject var state: AppState
    
    var body: some View {
        ZStack {
            AnimatedOceanBackground(health: state.oceanHealth)
            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    impactHeader
                    impactStats
                    LifetimePlasticChart()
                        .padding(.horizontal, 20)
                    OceanHealthNarrativeCard(phase: state.oceanPhase)
                        .padding(.horizontal, 20)
                    Spacer(minLength: 44)
                }
            }
        }
    }
    
    var impactHeader: some View {
        VStack(spacing: 8) {
            Text("Your Impact")
                .font(.system(size: 26, weight: .heavy, design: .rounded))
                .foregroundColor(.white).padding(.top, 60)
                .accessibilityAddTraits(.isHeader)
            Text("Every gram of plastic you intercept is\none less fragment in a sea creature's world.")
                .font(.system(size: 13, weight: .medium))
                .foregroundColor(.white.opacity(0.62))
                .multilineTextAlignment(.center).padding(.horizontal, 28)
        }
    }
    
    var impactStats: some View {
        VStack(spacing: 12) {
            ImpactEquivRow(
                icon: "waterbottle.fill",
                color: Color(red: 0.2, green: 0.65, blue: 1.0),
                value: "\(state.bottlesSaved)",
                label: "Plastic Bottles Diverted"
            )
            ImpactEquivRow(
                icon: "bag.fill",
                color: OceanTheme.teal,
                value: "\(state.bagsSaved)",
                label: "Plastic Bags Prevented"
            )
            ImpactEquivRow(
                icon: "leaf.fill",
                color: OceanTheme.seaGreen,
                value: String(format: "%.4f kg", state.co2SavedKg),
                label: "CO₂ Avoided"
            )
            ImpactEquivRow(
                icon: "fish.fill",
                color: OceanTheme.teal,
                value: String(format: "%.2f m²", state.oceanAreaCleaned),
                label: "Ocean Area Protected"
            )
            ImpactEquivRow(
                icon: "archivebox.fill",
                color: OceanTheme.gold,
                value: String(format: "%.1f g", state.totalPlastic),
                label: "Total Grams Intercepted"
            )
            ImpactEquivRow(
                icon: "camera.viewfinder",
                color: OceanTheme.coral,
                value: "\(state.totalScansCount)",
                label: "Total Items Scanned"
            )
        }
        .padding(.horizontal, 20)
    }
}

struct LifetimePlasticChart: View {
    @EnvironmentObject var state: AppState
    @State private var animHeights: [CGFloat] = []
    @State private var selectedIndex: Int? = nil
    
    private var data: [(label: String, grams: Double)] { state.lifetimeChartData() }
    private var maxVal: Double { max(data.map(\.grams).max() ?? 1, 1) }
    private var totalGrams: Double { data.map(\.grams).reduce(0, +) }
    
    private func targetHeights() -> [CGFloat] {
        data.map { max(6, CGFloat($0.grams / maxVal) * 90) }
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            // Header
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Lifetime Plastic Saved")
                        .font(.system(size: 13, weight: .bold)).foregroundColor(.white)
                    Text("Last 6 months")
                        .font(.system(size: 10)).foregroundColor(.white.opacity(0.45))
                }
                Spacer()
                VStack(alignment: .trailing, spacing: 2) {
                    Text(String(format: "%.1f g", totalGrams))
                        .font(.system(size: 14, weight: .heavy, design: .rounded))
                        .foregroundColor(OceanTheme.teal)
                        .contentTransition(.numericText())
                        .animation(.spring(), value: totalGrams)
                    Text("total").font(.system(size: 9)).foregroundColor(.white.opacity(0.4))
                }
            }
            
            // Selected detail
            if let idx = selectedIndex, idx < data.count {
                HStack {
                    Text(data[idx].label)
                        .font(.system(size: 11, weight: .bold)).foregroundColor(OceanTheme.teal)
                    Spacer()
                    Text(String(format: "%.1f g", data[idx].grams))
                        .font(.system(size: 11, weight: .heavy)).foregroundColor(.white)
                }
                .padding(.horizontal, 8).padding(.vertical, 5)
                .background(OceanTheme.teal.opacity(0.12)).cornerRadius(8)
                .transition(.opacity)
            }
            
            // Bars
            HStack(alignment: .bottom, spacing: 8) {
                ForEach(Array(data.enumerated()), id: \.offset) { idx, item in
                    VStack(spacing: 4) {
                        if item.grams > 0 {
                            Text(String(format: "%.0f", item.grams))
                                .font(.system(size: 8, weight: .bold))
                                .foregroundColor(OceanTheme.teal)
                                .contentTransition(.numericText())
                        }
                        RoundedRectangle(cornerRadius: 6)
                            .fill(selectedIndex == idx
                                  ? AnyShapeStyle(OceanTheme.gold)
                                  : AnyShapeStyle(LinearGradient(
                                    colors: [OceanTheme.teal, OceanTheme.seaGreen],
                                    startPoint: .bottom, endPoint: .top)))
                            .frame(height: idx < animHeights.count ? animHeights[idx] : 6)
                            .overlay(
                                RoundedRectangle(cornerRadius: 6)
                                    .stroke(selectedIndex == idx ? OceanTheme.gold : Color.clear, lineWidth: 2)
                            )
                        Text(item.label)
                            .font(.system(size: 9, weight: selectedIndex == idx ? .bold : .regular))
                            .foregroundColor(selectedIndex == idx ? OceanTheme.gold : .white.opacity(0.5))
                    }
                    .frame(maxWidth: .infinity)
                    .onTapGesture {
                        withAnimation(.spring(response: 0.3, dampingFraction: 0.7)) {
                            selectedIndex = selectedIndex == idx ? nil : idx
                        }
                        SoundManager.shared.hapticLight()
                    }
                    .accessibilityLabel("\(item.label): \(String(format: "%.1f", item.grams)) grams")
                }
            }
            .frame(height: 110)
            
            Text("Tap a bar to see monthly detail")
                .font(.system(size: 9)).foregroundColor(.white.opacity(0.3))
                .frame(maxWidth: .infinity, alignment: .center)
        }
        .padding(14)
        .background(Color.white.opacity(0.07))
        .cornerRadius(14)
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.10), lineWidth: 1))
        .onAppear {
            // Initialise heights at zero then spring up
            animHeights = Array(repeating: 6, count: data.count)
            let targets = targetHeights()
            for i in targets.indices {
                withAnimation(.spring(response: 0.6, dampingFraction: 0.65).delay(Double(i) * 0.07)) {
                    animHeights[i] = targets[i]
                }
            }
        }
        .onChange(of: state.lifetimeScans) { _, _ in
            let targets = targetHeights()
            if animHeights.count != targets.count {
                animHeights = Array(repeating: 6, count: targets.count)
            }
            withAnimation(.spring(response: 0.6, dampingFraction: 0.65)) {
                for i in targets.indices { animHeights[i] = targets[i] }
            }
        }
    }
}



struct ImpactEquivRow: View {
    let icon: String; let color: Color; let value: String; let label: String
    @State private var shown = false
    var body: some View {
        HStack(spacing: 14) {
            ZStack {
                Circle().fill(color.opacity(0.16)).frame(width: 48, height: 48)
                Image(systemName: icon).font(.system(size: 20, weight: .bold)).foregroundColor(color)
            }
            VStack(alignment: .leading, spacing: 3) {
                Text(label).font(.system(size: 11, weight: .semibold)).foregroundColor(.white.opacity(0.6))
                Text(value).font(.system(size: 19, weight: .heavy, design: .rounded)).foregroundColor(.white)
                    .contentTransition(.numericText())
            }
            Spacer()
        }
        .padding(14).background(Color.white.opacity(0.08)).cornerRadius(14)
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(color.opacity(0.22), lineWidth: 1))
        .opacity(shown ? 1 : 0).offset(x: shown ? 0 : -24)
        .onAppear { withAnimation(.spring(response: 0.55, dampingFraction: 0.78).delay(0.1)) { shown = true } }
        .accessibilityLabel("\(label): \(value)")
    }
}

struct OceanHealthNarrativeCard: View {
    let phase: OceanPhase
    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: "water.waves").font(.system(size: 22)).foregroundColor(phase.color)
            VStack(alignment: .leading, spacing: 3) {
                Text(phase.narrativeHeadline).font(.system(size: 14, weight: .bold)).foregroundColor(.white)
                Text(phase.narrativeBody).font(.system(size: 12)).foregroundColor(.white.opacity(0.65))
            }
            Spacer()
        }
        .padding(14).background(phase.color.opacity(0.12)).cornerRadius(14)
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(phase.color.opacity(0.3), lineWidth: 1))
        .animation(.easeInOut(duration: 0.5), value: phase)
    }
}

struct FlashcardsView: View {
    @EnvironmentObject var state: AppState
    @Binding var showConfetti: Bool
    @State private var currentIndex  = 0
    @State private var flipped       = false
    @State private var dragOffset    = CGSize.zero
    @State private var cardRotation  = 0.0
    @State private var masteredSet   = Set<Int>()
    @State private var showCompletion = false
    @State private var cardScale:    CGFloat = 1.0
    private let cards = LearningContentProvider.allCards
    
    var body: some View {
        ZStack {
            AnimatedOceanBackground(health: state.oceanHealth)
            if showCompletion {
                FlashcardCompletionView {
                    withAnimation { showCompletion = false; currentIndex = 0; masteredSet = [] }
                }
            } else {
                VStack(spacing: 14) {
                    Text("Recycle Facts")
                        .font(.system(size: 24, weight: .heavy, design: .rounded))
                        .foregroundColor(.white).padding(.top, 58)
                        .accessibilityAddTraits(.isHeader)
                    progressHeader
                    dotsRow
                    cardStack
                    gotItButton
                    Text("\(currentIndex + 1) / \(cards.count)")
                        .font(.system(size: 12)).foregroundColor(.white.opacity(0.38))
                    Spacer()
                }
            }
        }
    }
    
    var progressHeader: some View {
        VStack(spacing: 5) {
            HStack {
                Text("Mastered: \(masteredSet.count)/\(cards.count)")
                    .font(.system(size: 11, weight: .semibold)).foregroundColor(.white.opacity(0.6))
                Spacer()
                Text("Tap to flip · Swipe to navigate")
                    .font(.system(size: 10)).foregroundColor(.white.opacity(0.38))
            }
            GeometryReader { g in
                ZStack(alignment: .leading) {
                    RoundedRectangle(cornerRadius: 3).fill(Color.white.opacity(0.09)).frame(height: 5)
                    RoundedRectangle(cornerRadius: 3)
                        .fill(LinearGradient(colors: [OceanTheme.teal, OceanTheme.seaGreen],
                                             startPoint: .leading, endPoint: .trailing))
                        .frame(
                            width: g.size.width * CGFloat(masteredSet.count) / CGFloat(max(1, cards.count)),
                            height: 5
                        )
                        .animation(.spring(), value: masteredSet.count)
                }
            }.frame(height: 5)
        }.padding(.horizontal, 24)
    }
    
    var dotsRow: some View {
        HStack(spacing: 6) {
            ForEach(0..<cards.count, id: \.self) { i in
                Circle()
                    .fill(masteredSet.contains(i)
                          ? OceanTheme.teal
                          : i == currentIndex ? Color.white : Color.white.opacity(0.25))
                    .frame(width: i == currentIndex ? 9 : 6, height: i == currentIndex ? 9 : 6)
                    .animation(.spring(), value: currentIndex)
            }
        }
    }
    
    var cardStack: some View {
        ZStack {
            if currentIndex + 1 < cards.count {
                RoundedRectangle(cornerRadius: 22)
                    .fill(cards[currentIndex + 1].color.opacity(0.45))
                    .frame(height: 280).padding(.horizontal, 30).offset(y: 10).scaleEffect(0.95)
            }
            ZStack {
                if !flipped { FlashCardFront(card: cards[currentIndex]) }
                else {
                    FlashCardBack(card: cards[currentIndex])
                        .rotation3DEffect(.degrees(180), axis: (x: 0, y: 1, z: 0))
                }
            }
            .frame(height: 280).padding(.horizontal, 22)
            .rotation3DEffect(.degrees(cardRotation), axis: (x: 0, y: 1, z: 0))
            .scaleEffect(cardScale).offset(x: dragOffset.width)
            .gesture(
                DragGesture()
                    .onChanged { v in
                        dragOffset = v.translation
                        cardScale  = 1.0 - min(abs(v.translation.width) / 600, 0.04)
                    }
                    .onEnded { v in
                        if v.translation.width < -55     { goNext() }
                        else if v.translation.width > 55 { goPrev() }
                        withAnimation(.spring()) { dragOffset = .zero; cardScale = 1.0 }
                    }
            )
            .onTapGesture { flipCard() }
            .accessibilityLabel(flipped
                                ? "Fact: \(cards[currentIndex].backFact)"
                                : "Question: \(cards[currentIndex].frontTitle). Tap to flip.")
        }
    }
    
    @ViewBuilder
    var gotItButton: some View {
        if flipped && !masteredSet.contains(currentIndex) {
            Button {
                masteredSet.insert(currentIndex)
                state.flashcardsLearned = masteredSet.count
                SoundManager.shared.playBubble()
                state.checkAchievements()
                if masteredSet.count == cards.count {
                    showConfetti = true
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
                        withAnimation { showCompletion = true }
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) { showConfetti = false }
                } else { goNext() }
            } label: {
                Label("Got it", systemImage: "checkmark.circle.fill")
                    .font(.system(size: 14, weight: .bold)).foregroundColor(.white)
                    .padding(.horizontal, 22).padding(.vertical, 10)
                    .background(OceanTheme.seaGreen).cornerRadius(12)
                    .shadow(color: OceanTheme.seaGreen.opacity(0.4), radius: 6)
            }
            .transition(.scale.combined(with: .opacity))
            .accessibilityLabel("Mark card as mastered")
        }
    }
    
    private func flipCard() {
        SoundManager.shared.hapticLight()
        withAnimation(.spring(response: 0.48, dampingFraction: 0.7)) { cardRotation = flipped ? 0 : 180 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.24) { flipped.toggle() }
    }
    private func goNext() {
        guard currentIndex < cards.count - 1 else { return }
        withAnimation(.spring(response: 0.38, dampingFraction: 0.82)) {
            currentIndex += 1; flipped = false; cardRotation = 0
        }
    }
    private func goPrev() {
        guard currentIndex > 0 else { return }
        withAnimation(.spring(response: 0.38, dampingFraction: 0.82)) {
            currentIndex -= 1; flipped = false; cardRotation = 0
        }
    }
}

struct FlashcardCompletionView: View {
    let onReset: () -> Void
    @State private var shown = false
    var body: some View {
        VStack(spacing: 20) {
            Text("🎓").font(.system(size: 68)).scaleEffect(shown ? 1 : 0.3)
                .animation(.spring(response: 0.5, dampingFraction: 0.5).delay(0.1), value: shown)
            Text("Eco Scholar")
                .font(.system(size: 26, weight: .heavy, design: .rounded)).foregroundColor(OceanTheme.teal)
            Text("All 12 facts mastered.\nKnowledge is the first act of protection.")
                .font(.system(size: 14)).foregroundColor(.white.opacity(0.72))
                .multilineTextAlignment(.center).padding(.horizontal, 30)
            Button(action: onReset) {
                Text("Review Again")
                    .font(.system(size: 15, weight: .bold)).foregroundColor(.white)
                    .frame(maxWidth: .infinity).frame(height: 48).background(OceanTheme.teal).cornerRadius(13)
            }.padding(.horizontal, 40)
        }
        .opacity(shown ? 1 : 0).offset(y: shown ? 0 : 28)
        .onAppear { withAnimation(.spring(response: 0.58, dampingFraction: 0.72)) { shown = true } }
    }
}

struct FlashCardFront: View {
    let card: FlashCard
    @State private var shown = false
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 22)
                .fill(LinearGradient(colors: [card.color.opacity(0.82), card.color],
                                     startPoint: .topLeading, endPoint: .bottomTrailing))
                .shadow(color: card.color.opacity(0.38), radius: 14, x: 0, y: 7)
            VStack(spacing: 12) {
                Text(card.emoji).font(.system(size: 52)).scaleEffect(shown ? 1 : 0.5).opacity(shown ? 1 : 0)
                Text(card.frontTitle)
                    .font(.system(size: 18, weight: .heavy, design: .rounded)).foregroundColor(.white)
                    .multilineTextAlignment(.center).padding(.horizontal, 14)
                Text(card.frontSubtitle).font(.system(size: 12)).foregroundColor(.white.opacity(0.72))
                HStack(spacing: 5) {
                    Image(systemName: card.category.icon).font(.system(size: 9)).foregroundColor(.white.opacity(0.45))
                    Text(card.category.rawValue).font(.system(size: 9)).foregroundColor(.white.opacity(0.45))
                }
                Label("Tap to flip", systemImage: "hand.tap.fill").font(.caption2).foregroundColor(.white.opacity(0.48))
            }
        }
        .onAppear { withAnimation(.spring(response: 0.48, dampingFraction: 0.6).delay(0.08)) { shown = true } }
    }
}

struct FlashCardBack: View {
    let card: FlashCard
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 22)
                .fill(Color(red: 0.07, green: 0.14, blue: 0.26))
                .shadow(color: card.color.opacity(0.28), radius: 14, x: 0, y: 7)
            VStack(alignment: .leading, spacing: 11) {
                Label("Fact", systemImage: "book.fill")
                    .font(.system(size: 12, weight: .bold)).foregroundColor(card.color)
                Text(card.backFact).font(.system(size: 13, weight: .medium)).foregroundColor(.white)
                    .fixedSize(horizontal: false, vertical: true)
                Divider().background(Color.white.opacity(0.14))
                HStack(alignment: .top, spacing: 7) {
                    Image(systemName: "lightbulb.fill").foregroundColor(OceanTheme.gold).font(.system(size: 11))
                    Text(card.backTip).font(.system(size: 12)).foregroundColor(.white.opacity(0.72))
                        .fixedSize(horizontal: false, vertical: true)
                }
            }.padding(20)
        }
    }
}

struct AboutView: View {
    @EnvironmentObject var state: AppState
    @State private var float = false
    
    var body: some View {
        ZStack {
            AnimatedOceanBackground(health: state.oceanHealth)
            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    aboutHeader
                    statsRow
                    aboutCards
                    sealife
                    Text("Made with care, for the ocean.")
                        .font(.system(size: 12)).foregroundColor(.white.opacity(0.4))
                    Spacer(minLength: 44)
                }
                .padding(.horizontal, 20)
            }
        }
        .onAppear { float = true }
    }
    
    var aboutHeader: some View {
        VStack(spacing: 8) {
            ZStack {
                Circle().fill(OceanTheme.teal.opacity(0.14)).frame(width: 96, height: 96)
                Image(systemName: "water.waves")
                    .font(.system(size: 44, weight: .light)).foregroundColor(OceanTheme.teal)
                    .offset(y: float ? -5 : 5)
                    .animation(.easeInOut(duration: 2.2).repeatForever(autoreverses: true), value: float)
            }
            Text("EcoSafe")
                .font(.system(size: 26, weight: .heavy, design: .rounded)).foregroundColor(.white)
            Text("Swift Student Challenge 2026")
                .font(.system(size: 11)).foregroundColor(.white.opacity(0.42))
            HStack(spacing: 6) {
                Circle().fill(state.oceanPhase.color).frame(width: 7, height: 7)
                Text("Ocean: \(state.oceanPhase.label)")
                    .font(.system(size: 11, weight: .semibold)).foregroundColor(state.oceanPhase.color)
            }
            .padding(.horizontal, 12).padding(.vertical, 5)
            .background(state.oceanPhase.color.opacity(0.12)).cornerRadius(10)
        }.padding(.top, 52)
    }
    
    var statsRow: some View {
        HStack(spacing: 8) {
            MiniStat(emoji: "♻️", value: "\(state.totalScansCount)", label: "Scans")
            MiniStat(emoji: "🔥", value: "\(state.streakDays)",       label: "Streak")
            MiniStat(emoji: "⭐", value: "Lv.\(state.oceanLevel)",    label: state.levelTitle)
            MiniStat(emoji: "🎮", value: "\(state.gamesPlayed)",      label: "Games")
        }
    }
    
    var aboutCards: some View {
        VStack(spacing: 12) {
            AboutCard(icon: "water.waves",         title: "Our Mission",
                      text: "EcoSafe exists to close the gap between intention and action. Knowing that plastic is harmful isn't enough — practising the right behaviour is.")
            AboutCard(icon: "chart.bar.fill",      title: "The Numbers",
                      text: "8 million tonnes of plastic enter the ocean each year. Missorting is one of the most preventable causes of plastic leakage into nature.")
            AboutCard(icon: "gamecontroller.fill", title: "The Game",
                      text: "Ocean Rescue simulates real sorting decisions under time pressure. Accuracy and speed build genuine muscle memory.")
            AboutCard(icon: "rosette",             title: "The Vision",
                      text: "Small individual actions, sustained over time, produce measurable environmental change. EcoSafe makes that visible.")
        }
    }
    
    var sealife: some View {
        HStack(spacing: 16) {
            ForEach(["🐬","🐢","🦈","🐙","🐋"], id: \.self) { e in
                Text(e).font(.system(size: 26))
                    .offset(y: float ? -4 : 4)
                    .animation(.easeInOut(duration: 2.0).repeatForever(autoreverses: true), value: float)
            }
        }.padding(.vertical, 8)
    }
}

struct MiniStat: View {
    let emoji: String; let value: String; let label: String
    var body: some View {
        VStack(spacing: 3) {
            Text(emoji).font(.system(size: 18))
            Text(value).font(.system(size: 14, weight: .heavy, design: .rounded)).foregroundColor(.white)
            Text(label).font(.system(size: 8)).foregroundColor(.white.opacity(0.5))
        }
        .frame(maxWidth: .infinity).padding(9)
        .background(Color.white.opacity(0.07)).cornerRadius(10)
    }
}

struct AboutCard: View {
    let icon: String; let title: String; let text: String
    var body: some View {
        VStack(alignment: .leading, spacing: 9) {
            Label(title, systemImage: icon)
                .font(.system(size: 14, weight: .bold)).foregroundColor(OceanTheme.teal)
            Text(text).font(.system(size: 12, weight: .medium)).foregroundColor(.white.opacity(0.7))
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(15).frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.07)).cornerRadius(14)
        .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.10), lineWidth: 1))
    }
}
