import SwiftUI
import UIKit

struct CinematicIntroView: View {
    let onComplete: (String) -> Void   
    
    @State private var sceneIndex: Int    = 0
    @State private var textOpacity        = 0.0
    @State private var iconOpacity        = 0.0
    @State private var bgPhase            = 0.0
    @State private var skipOpacity        = 0.0
    @State private var iconScale: CGFloat = 0.6
    @State private var particleAngle      = 0.0
    @State private var playerName         = ""
    @State private var nameFieldShown     = false
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    
    private let scenes: [IntroScene] = [
        IntroScene(
            icon: "globe.asia.australia.fill",
            headline: "8 million tonnes.",
            body: "That's how much plastic enters our ocean every single year. The weight of 800 Eiffel Towers — vanishing beneath the waves.",
            accentColor: Color(red: 1.00, green: 0.45, blue: 0.35),
            delay: 4.2
        ),
        IntroScene(
            icon: "fish.fill",
            headline: "Marine life can't choose.",
            body: "A sea turtle mistakes a plastic bag for a jellyfish. A seabird feeds bottle caps to its chicks. They have no warning label.",
            accentColor: Color(red: 0.20, green: 0.72, blue: 0.55),
            delay: 4.2
        ),
        IntroScene(
            icon: "microbe.fill",
            headline: "It never disappears.",
            body: "Plastic breaks into microparticles smaller than a grain of sand — and has been found in human blood, lungs, and unborn babies.",
            accentColor: Color(red: 1.00, green: 0.82, blue: 0.22),
            delay: 4.2
        ),
        IntroScene(
            icon: "hand.raised.fill",
            headline: "But you can change it.",
            body: "Every correctly sorted item is one less fragment in the sea. One habit, repeated daily, creates a measurable difference.",
            accentColor: Color(red: 0.00, green: 0.72, blue: 0.80),
            delay: 4.0
        ),
        IntroScene(
            icon: "water.waves",
            headline: "EcoSafe.",
            body: "Scan packaging. Learn the facts. Rescue the ocean. Your choices have consequences — and today, they can be good ones.",
            accentColor: Color(red: 0.13, green: 0.72, blue: 0.52),
            delay: 0
        ),
    ]
    
    private var currentScene: IntroScene { scenes[sceneIndex] }
    private var isLast: Bool { sceneIndex == scenes.count - 1 }
    
    var body: some View {
        ZStack {
            // ── Animated background ──────────────────────────────
            LinearGradient(
                colors: [
                    Color(red: 0.03, green: 0.07, blue: 0.18),
                    Color(red: 0.04, green: 0.15, blue: 0.32 + bgPhase * 0.06),
                    currentScene.accentColor.opacity(0.18 + bgPhase * 0.08)
                ],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            .animation(.easeInOut(duration: 0.8), value: sceneIndex)
            
            // ── Orbiting particles ───────────────────────────────
            if !reduceMotion {
                ForEach(0..<6) { i in
                    Circle()
                        .fill(currentScene.accentColor.opacity(0.12))
                        .frame(width: CGFloat(8 + i * 4), height: CGFloat(8 + i * 4))
                        .offset(
                            x: cos(particleAngle + Double(i) * .pi / 3) * 140,
                            y: sin(particleAngle + Double(i) * .pi / 3) * 140
                        )
                }
            }
            
            BubbleBackground()
            
            VStack(spacing: 0) {
                Spacer()
                
                // ── Icon ─────────────────────────────────────────
                ZStack {
                    ForEach(0..<3) { i in
                        Circle()
                            .stroke(currentScene.accentColor.opacity(0.08 + Double(i) * 0.04), lineWidth: 1)
                            .frame(width: CGFloat(90 + i * 38), height: CGFloat(90 + i * 38))
                            .scaleEffect(iconOpacity > 0.5 ? 1.0 : 0.5 + Double(i) * 0.1)
                            .animation(.easeOut(duration: 0.7), value: iconOpacity)
                    }
                    Circle()
                        .fill(currentScene.accentColor.opacity(0.16))
                        .frame(width: 100, height: 100)
                        .scaleEffect(iconScale).opacity(iconOpacity)
                    Image(systemName: currentScene.icon)
                        .font(.system(size: 46, weight: .light))
                        .foregroundColor(currentScene.accentColor)
                        .scaleEffect(iconScale).opacity(iconOpacity)
                }
                .animation(.easeInOut(duration: 0.5), value: sceneIndex)
                .accessibilityHidden(true)
                
                Spacer().frame(height: 32)
                
                // ── Text ─────────────────────────────────────────
                VStack(spacing: 14) {
                    Text(currentScene.headline)
                        .font(.system(size: 28, weight: .heavy, design: .rounded))
                        .foregroundColor(.white)
                        .multilineTextAlignment(.center)
                    Text(currentScene.body)
                        .font(.system(size: 15, weight: .medium))
                        .foregroundColor(.white.opacity(0.72))
                        .multilineTextAlignment(.center)
                        .lineSpacing(5)
                        .padding(.horizontal, 10)
                }
                .opacity(textOpacity)
                .padding(.horizontal, 32)
                .accessibilityElement(children: .combine)
                .accessibilityLabel("\(currentScene.headline). \(currentScene.body)")
                
                Spacer()
                Spacer()
                
                // ── Navigation ───────────────────────────────────
                VStack(spacing: 14) {
                    // Scene dots
                    HStack(spacing: 8) {
                        ForEach(0..<scenes.count, id: \.self) { i in
                            Capsule()
                                .fill(i == sceneIndex
                                      ? currentScene.accentColor
                                      : (i < sceneIndex ? currentScene.accentColor.opacity(0.45) : Color.white.opacity(0.20)))
                                .frame(width: i == sceneIndex ? 22 : 7, height: 7)
                                .animation(.spring(response: 0.4, dampingFraction: 0.7), value: sceneIndex)
                        }
                    }
                    .padding(.bottom, 4)
                    
                    if isLast {
                        // Name entry field — shown with delay on last scene
                        if nameFieldShown {
                            VStack(spacing: 8) {
                                Text("What should we call you?")
                                    .font(.system(size: 12, weight: .semibold))
                                    .foregroundColor(.white.opacity(0.55))
                                TextField("Your name (optional)", text: $playerName)
                                    .font(.system(size: 16, weight: .semibold, design: .rounded))
                                    .foregroundColor(.white)
                                    .multilineTextAlignment(.center)
                                    .padding(.horizontal, 18).padding(.vertical, 11)
                                    .background(Color.white.opacity(0.10))
                                    .cornerRadius(12)
                                    .overlay(RoundedRectangle(cornerRadius: 12)
                                        .stroke(currentScene.accentColor.opacity(0.45), lineWidth: 1))
                                    .submitLabel(.done)
                                    .onSubmit { }
                            }
                            .padding(.horizontal, 28)
                            .transition(.move(edge: .bottom).combined(with: .opacity))
                        }
                        
                        // Final CTA — tap to enter
                        Button {
                            SoundManager.shared.playTap()
                            SoundManager.shared.hapticLight()
                            onComplete(playerName.trimmingCharacters(in: .whitespaces))
                        } label: {
                            HStack(spacing: 10) {
                                Image(systemName: "water.waves").font(.system(size: 16, weight: .bold))
                                Text("Start Protecting the Ocean")
                                    .font(.system(size: 17, weight: .heavy, design: .rounded))
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity).frame(height: 56)
                            .background(LinearGradient(
                                colors: [currentScene.accentColor, OceanTheme.teal],
                                startPoint: .leading, endPoint: .trailing))
                            .cornerRadius(18)
                            .shadow(color: currentScene.accentColor.opacity(0.5), radius: 16, x: 0, y: 7)
                        }
                        .padding(.horizontal, 28)
                        .transition(.scale.combined(with: .opacity))
                        .accessibilityLabel("Begin EcoSafe")
                    } else {
                        Button {
                            SoundManager.shared.hapticLight()
                            SoundManager.shared.playTap()
                            advanceScene()
                        } label: {
                            HStack(spacing: 8) {
                                Text("Continue")
                                    .font(.system(size: 16, weight: .semibold))
                                Image(systemName: "arrow.right")
                                    .font(.system(size: 14, weight: .bold))
                            }
                            .foregroundColor(.white.opacity(0.85))
                            .frame(maxWidth: .infinity).frame(height: 50)
                            .background(Color.white.opacity(0.10))
                            .cornerRadius(14)
                            .overlay(RoundedRectangle(cornerRadius: 14)
                                .stroke(Color.white.opacity(0.18), lineWidth: 1))
                        }
                        .padding(.horizontal, 28)
                    }
                    
                    Button {
                        SoundManager.shared.playTap()
                        onComplete(playerName.trimmingCharacters(in: .whitespaces))
                    } label: {
                        Text("Skip intro")
                            .font(.system(size: 12))
                            .foregroundColor(.white.opacity(0.35))
                    }
                    .opacity(skipOpacity)
                }
                .padding(.bottom, 58)
            }
        }
        .onAppear { beginScene() }
        .onAppear {
            guard !reduceMotion else { return }
            withAnimation(.linear(duration: 12).repeatForever(autoreverses: false)) {
                particleAngle = .pi * 2
            }
        }
    }
    
    private func beginScene() {
        textOpacity = 0; iconOpacity = 0; iconScale = 0.6
        nameFieldShown = false
        let d: Double = reduceMotion ? 0 : 0.22
        withAnimation(.spring(response: 0.52, dampingFraction: 0.62).delay(d)) {
            iconOpacity = 1; iconScale = 1
        }
        withAnimation(.easeOut(duration: 0.55).delay(reduceMotion ? 0 : 0.5)) { textOpacity = 1 }
        withAnimation(.easeIn(duration: 0.8).delay(0.9)) { skipOpacity = 1 }
        // Show name field on last scene after text appears
        if isLast {
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) {
                withAnimation(.spring(response: 0.5, dampingFraction: 0.72)) { nameFieldShown = true }
            }
            return
        }
        guard !reduceMotion else { return }
        let captured = sceneIndex
        DispatchQueue.main.asyncAfter(deadline: .now() + scenes[captured].delay) {
            guard sceneIndex == captured else { return }
            advanceScene()
        }
    }
    
    private func advanceScene() {
        guard sceneIndex < scenes.count - 1 else { return }
        withAnimation(.easeIn(duration: 0.3)) { textOpacity = 0; iconOpacity = 0; iconScale = 0.6 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.36) {
            sceneIndex += 1
            withAnimation(.easeInOut(duration: 0.6)) { bgPhase = Double(sceneIndex) * 0.2 }
            beginScene()
        }
    }
}

private struct IntroScene {
    let icon: String; let headline: String; let body: String
    let accentColor: Color; let delay: Double
}

struct MotivationOutroView: View {
    let onComplete: () -> Void
    
    @State private var panelIndex: Int    = 0
    @State private var textOpacity        = 0.0
    @State private var iconScale: CGFloat = 0.5
    @State private var iconOpacity        = 0.0
    @State private var starScale: CGFloat = 0.0
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    
    private let panels: [OutroPanel] = [
        OutroPanel(
            icon: "🌱",
            headline: "You just made a difference.",
            body: "The plastic you intercepted today won't spend 450 years in the ocean. That's not small — that's real.",
            color: Color(red: 0.13, green: 0.72, blue: 0.52)
        ),
        OutroPanel(
            icon: "🐠",
            headline: "A sea creature thanks you.",
            body: "Somewhere in the Pacific, a fish that would have choked on your recycled bottle is still swimming. You'll never meet — but it's alive.",
            color: Color(red: 0.00, green: 0.72, blue: 0.80)
        ),
        OutroPanel(
            icon: "🌊",
            headline: "Habit is the real power.",
            body: "One scan today. One tomorrow. Compounded over a year — that's hundreds of items diverted. The ocean has a long memory.",
            color: Color(red: 0.20, green: 0.60, blue: 1.00)
        ),
        OutroPanel(
            icon: "💎",
            headline: "Keep the streak alive.",
            body: "Come back tomorrow. Every day you return, the ocean gets a little stronger — and so does the version of you that cares about it.",
            color: Color(red: 0.72, green: 0.55, blue: 1.00)
        ),
    ]
    
    private var current: OutroPanel { panels[panelIndex] }
    private var isLast: Bool { panelIndex == panels.count - 1 }
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(red: 0.03, green: 0.08, blue: 0.20),
                         current.color.opacity(0.22)],
                startPoint: .topLeading, endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            .animation(.easeInOut(duration: 0.7), value: panelIndex)
            
            BubbleBackground()
            
            VStack(spacing: 0) {
                Spacer()
                
                // Emoji icon
                Text(current.icon)
                    .font(.system(size: 72))
                    .scaleEffect(iconScale).opacity(iconOpacity)
                    .shadow(color: current.color.opacity(0.4), radius: starScale * 20)
                    .accessibilityHidden(true)
                
                Spacer().frame(height: 28)
                
                VStack(spacing: 14) {
                    Text(current.headline)
                        .font(.system(size: 24, weight: .heavy, design: .rounded))
                        .foregroundColor(.white).multilineTextAlignment(.center)
                    Text(current.body)
                        .font(.system(size: 15, weight: .medium))
                        .foregroundColor(.white.opacity(0.72))
                        .multilineTextAlignment(.center).lineSpacing(5)
                        .padding(.horizontal, 10)
                }
                .opacity(textOpacity).padding(.horizontal, 32)
                
                Spacer()
                Spacer()
                
                VStack(spacing: 14) {
                    HStack(spacing: 8) {
                        ForEach(0..<panels.count, id: \.self) { i in
                            Circle()
                                .fill(i == panelIndex ? current.color : Color.white.opacity(0.22))
                                .frame(width: i == panelIndex ? 9 : 6, height: i == panelIndex ? 9 : 6)
                                .animation(.spring(), value: panelIndex)
                        }
                    }
                    
                    if isLast {
                        Button {
                            SoundManager.shared.playTap()
                            SoundManager.shared.hapticLight()
                            onComplete()
                        } label: {
                            Text("Let's go 🌊")
                                .font(.system(size: 18, weight: .heavy, design: .rounded))
                                .foregroundColor(.white)
                                .frame(maxWidth: .infinity).frame(height: 54)
                                .background(LinearGradient(
                                    colors: [current.color, OceanTheme.teal],
                                    startPoint: .leading, endPoint: .trailing))
                                .cornerRadius(16)
                                .shadow(color: current.color.opacity(0.5), radius: 14, x: 0, y: 6)
                        }
                        .padding(.horizontal, 28)
                    } else {
                        Button {
                            SoundManager.shared.hapticLight()
                            advancePanel()
                        } label: {
                            Text("Next")
                                .font(.system(size: 16, weight: .semibold))
                                .foregroundColor(.white.opacity(0.85))
                                .frame(maxWidth: .infinity).frame(height: 48)
                                .background(Color.white.opacity(0.10)).cornerRadius(14)
                        }
                        .padding(.horizontal, 28)
                    }
                    
                    Button { SoundManager.shared.playTap(); onComplete() } label: {
                        Text("Skip").font(.system(size: 12)).foregroundColor(.white.opacity(0.35))
                    }
                }
                .padding(.bottom, 54)
            }
        }
        .onAppear { beginPanel() }
    }
    
    private func beginPanel() {
        textOpacity = 0; iconOpacity = 0; iconScale = 0.5; starScale = 0
        let d: Double = reduceMotion ? 0 : 0.2
        withAnimation(.spring(response: 0.5, dampingFraction: 0.55).delay(d)) {
            iconScale = 1; iconOpacity = 1
        }
        withAnimation(.easeInOut(duration: 0.8).delay(reduceMotion ? 0 : 0.38)) {
            textOpacity = 1
        }
        withAnimation(.easeInOut(duration: 1.2).delay(reduceMotion ? 0 : 0.5).repeatForever(autoreverses: true)) {
            starScale = 1
        }
    }
    
    private func advancePanel() {
        guard panelIndex < panels.count - 1 else { return }
        withAnimation(.easeIn(duration: 0.25)) { textOpacity = 0; iconOpacity = 0 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
            panelIndex += 1; beginPanel()
        }
    }
}

private struct OutroPanel {
    let icon: String; let headline: String; let body: String; let color: Color
}
struct CameraView: View {
    let onScanComplete: () -> Void
    let onPlayGame:     () -> Void
    
    @State private var phase: ScanPhase   = .scanning
    @State private var scanLineY: CGFloat = 0
    @State private var pulseRing          = false
    @State private var itemScale: CGFloat = 0.7
    @State private var cornerGlow         = false
    @State private var scanLabelOpacity   = 1.0
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) var reduceMotion
    
    enum ScanPhase { case scanning, detected }
    
    private let detectedType: TrashType = TrashType.allCases.randomElement() ?? .plastic
    
    var body: some View {
        ZStack {
            Color(red: 0.04, green: 0.09, blue: 0.20).ignoresSafeArea()
            BubbleBackground()
            
            VStack(spacing: 0) {
                HStack {
                    Button {
                        SoundManager.shared.hapticLight()
                        dismiss()
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 28))
                            .foregroundColor(.white.opacity(0.65))
                    }
                    .accessibilityLabel("Close scanner")
                    Spacer()
                    Text("Scan Packaging")
                        .font(.system(size: 15, weight: .bold)).foregroundColor(.white)
                    Spacer()
                    Color.clear.frame(width: 28)
                }
                .padding(.horizontal, 20).padding(.top, 52).padding(.bottom, 20)
                
                Spacer()
                
                if phase == .scanning {
                    scanningView
                } else {
                    detectedView
                        .transition(.asymmetric(
                            insertion: .scale(scale: 0.85).combined(with: .opacity),
                            removal: .opacity))
                }
                
                Spacer()
            }
        }
        .onAppear { startScan() }
    }
    
    var scanningView: some View {
        VStack(spacing: 24) {
            ZStack {
                // Pulsing corner frame
                RoundedRectangle(cornerRadius: 22)
                    .stroke(OceanTheme.teal.opacity(cornerGlow ? 0.9 : 0.45), lineWidth: 2)
                    .frame(width: 256, height: 256)
                    .animation(.easeInOut(duration: 0.9).repeatForever(autoreverses: true), value: cornerGlow)
                
                // Corner accents
                ForEach(0..<4) { i in ScanCorner().rotationEffect(.degrees(Double(i) * 90)) }
                
                // Scan line
                if !reduceMotion {
                    Rectangle()
                        .fill(LinearGradient(
                            colors: [.clear, OceanTheme.teal.opacity(0.8), .clear],
                            startPoint: .leading, endPoint: .trailing))
                        .frame(width: 236, height: 2)
                        .offset(y: scanLineY)
                        .clipped()
                }
                
                // Pulse ring
                if !reduceMotion {
                    Circle()
                        .stroke(OceanTheme.teal.opacity(pulseRing ? 0 : 0.25), lineWidth: 1.5)
                        .frame(width: pulseRing ? 320 : 256, height: pulseRing ? 320 : 256)
                }
                
                // Centre indicator
                Circle()
                    .fill(OceanTheme.teal.opacity(0.18))
                    .frame(width: 24, height: 24)
                    .overlay(Circle().stroke(OceanTheme.teal, lineWidth: 1.5))
            }
            .frame(width: 280, height: 280)
            .accessibilityLabel("Camera viewfinder — point at packaging")
            
            VStack(spacing: 7) {
                Text("Point at packaging")
                    .font(.system(size: 19, weight: .bold, design: .rounded)).foregroundColor(.white)
                Text("Hold steady — detecting material…")
                    .font(.system(size: 13)).foregroundColor(.white.opacity(0.55))
                    .opacity(scanLabelOpacity)
                    .animation(.easeInOut(duration: 0.8).repeatForever(autoreverses: true), value: scanLabelOpacity)
            }
        }
    }
    
    var detectedView: some View {
        VStack(spacing: 22) {
            ZStack {
                Circle().fill(detectedType.color.opacity(0.14)).frame(width: 130, height: 130)
                Circle().stroke(detectedType.color, lineWidth: 2.5).frame(width: 130, height: 130)
                VStack(spacing: 6) {
                    Image(systemName: "checkmark.circle.fill")
                        .font(.system(size: 40, weight: .bold)).foregroundColor(detectedType.color)
                    Text(detectedType.label)
                        .font(.system(size: 13, weight: .bold)).foregroundColor(.white.opacity(0.85))
                }
            }
            .scaleEffect(itemScale)
            .onAppear {
                withAnimation(.spring(response: 0.4, dampingFraction: 0.58)) { itemScale = 1.0 }
            }
            .accessibilityLabel("\(detectedType.label) detected")
            
            VStack(spacing: 6) {
                Text(detectedType.label)
                    .font(.system(size: 20, weight: .heavy, design: .rounded)).foregroundColor(.white)
                Text(detectedType.recycleCode)
                    .font(.system(size: 12)).foregroundColor(detectedType.color)
            }
            
            HStack(spacing: 7) {
                Image(systemName: "lightbulb.fill").foregroundColor(OceanTheme.gold).font(.system(size: 12))
                Text(detectedType.fact)
                    .font(.system(size: 12)).foregroundColor(.white.opacity(0.68))
                    .fixedSize(horizontal: false, vertical: true)
            }
            .padding(.horizontal, 14).padding(.vertical, 10)
            .background(Color.white.opacity(0.07)).cornerRadius(12)
            .padding(.horizontal, 22)
            
            HStack(spacing: 12) {
                Button {
                    SoundManager.shared.playSuccess()
                    SoundManager.shared.hapticLight()
                    onScanComplete()
                    dismiss()
                } label: {
                    Label("Log It", systemImage: "checkmark.circle.fill")
                        .font(.system(size: 15, weight: .bold)).foregroundColor(.white)
                        .frame(maxWidth: .infinity).frame(height: 52)
                        .background(OceanTheme.seaGreen).cornerRadius(15)
                        .shadow(color: OceanTheme.seaGreen.opacity(0.4), radius: 8, x: 0, y: 4)
                }
                .accessibilityLabel("Log this \(detectedType.label) as recycled")
                
                Button {
                    SoundManager.shared.hapticLight()
                    dismiss()
                    onPlayGame()
                } label: {
                    Label("Rescue Game", systemImage: "gamecontroller.fill")
                        .font(.system(size: 15, weight: .bold)).foregroundColor(.white)
                        .frame(maxWidth: .infinity).frame(height: 52)
                        .background(OceanTheme.teal).cornerRadius(15)
                        .shadow(color: OceanTheme.teal.opacity(0.4), radius: 8, x: 0, y: 4)
                }
                .accessibilityLabel("Play Ocean Rescue game")
            }
            .padding(.horizontal, 24)
            
            // ── Recycle Tips Carousel ─────────────────────────
            RecycleTipsCarousel(highlightType: detectedType)
                .padding(.horizontal, 18)
                .padding(.top, 4)
        }
    }
    
    private func startScan() {
        cornerGlow = true
        if !reduceMotion {
            withAnimation(.linear(duration: 1.8).repeatForever(autoreverses: true)) { scanLineY = 110 }
            withAnimation(.easeInOut(duration: 1.2).repeatForever(autoreverses: false)) { pulseRing = true }
            withAnimation(.easeInOut(duration: 0.7).repeatForever(autoreverses: true).delay(0.4)) {
                scanLabelOpacity = 0.4
            }
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + EcoConfiguration.animScanAutoDetect) {
            SoundManager.shared.playBubble()
            SoundManager.shared.hapticLight()
            withAnimation(.spring(response: 0.5, dampingFraction: 0.68)) { phase = .detected }
        }
    }
}

struct ScanCorner: View {
    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 0) {
                Rectangle().fill(OceanTheme.teal).frame(width: 3, height: 22); Spacer()
            }
            HStack(spacing: 0) {
                Rectangle().fill(OceanTheme.teal).frame(width: 22, height: 3); Spacer()
            }
            Spacer()
        }
        .frame(width: 256, height: 256)
    }
}

struct LearnCardView: View {
    @Binding var showLearnCard: Bool
    @Binding var showScanView:  Bool
    
    private let tips: [(icon: String, color: Color, title: String, body: String)] = [
        ("1.circle.fill", Color(red: 0.2, green: 0.65, blue: 1.0),
         "Check the number", "Look for the recycling triangle on packaging. Numbers #1 (PET) and #2 (HDPE) are widely accepted."),
        ("drop.fill", OceanTheme.teal,
         "Rinse it first", "A quick rinse removes food residue — contaminated plastic is often rejected at sorting facilities."),
        ("archivebox.fill", OceanTheme.seaGreen,
         "Remove the label", "Paper labels slow down sorting machines. Peel them when possible before recycling."),
        ("bag.fill", Color(red: 0.42, green: 0.22, blue: 0.80),
         "Soft plastics go separately", "Plastic bags, wrap, and film must go to supermarket drop-off points — not your curbside bin."),
        ("flame.fill", OceanTheme.coral,
         "Never wish-cycle", "When unsure if something is recyclable, don't guess-recycle it. Contamination ruins entire batches."),
    ]
    
    @State private var tipIndex:       Int     = 0
    @State private var shown:          Bool    = false
    @State private var contentOpacity: Double  = 1.0
    @State private var cardOffset:     CGFloat = 0
    @State private var iconBounce:     Bool    = false
    
    var body: some View {
        ZStack {
            OceanTheme.gradient(health: 0.5).ignoresSafeArea()
            BubbleBackground()
            
            VStack(spacing: 0) {
                HStack {
                    Spacer()
                    Button {
                        SoundManager.shared.hapticLight()
                        showLearnCard = false
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .font(.system(size: 26)).foregroundColor(.white.opacity(0.55))
                    }
                    .accessibilityLabel("Close")
                }
                .padding(.horizontal, 22).padding(.top, 52)
                
                Spacer()
                
                // Card
                VStack(spacing: 22) {
                    let tip = tips[tipIndex]
                    
                    ZStack {
                        Circle().fill(tip.color.opacity(0.14)).frame(width: 92, height: 92)
                        Image(systemName: tip.icon)
                            .font(.system(size: 38, weight: .light)).foregroundColor(tip.color)
                    }
                    .scaleEffect(iconBounce ? 1.12 : 1.0)
                    .animation(.spring(response: 0.3, dampingFraction: 0.4), value: iconBounce)
                    
                    VStack(spacing: 10) {
                        Text("Tip \(tipIndex + 1) of \(tips.count)")
                            .font(.system(size: 10, weight: .bold))
                            .foregroundColor(.white.opacity(0.40)).tracking(1)
                        Text(tip.title)
                            .font(.system(size: 22, weight: .heavy, design: .rounded)).foregroundColor(.white)
                        Text(tip.body)
                            .font(.system(size: 14, weight: .medium))
                            .foregroundColor(.white.opacity(0.68))
                            .multilineTextAlignment(.center).lineSpacing(4)
                    }
                    .opacity(contentOpacity).offset(x: cardOffset)
                    
                    HStack(spacing: 7) {
                        ForEach(0..<tips.count, id: \.self) { i in
                            Circle()
                                .fill(i == tipIndex ? tip.color : Color.white.opacity(0.22))
                                .frame(width: i == tipIndex ? 9 : 5, height: i == tipIndex ? 9 : 5)
                                .animation(.spring(), value: tipIndex)
                        }
                    }
                }
                .padding(28)
                .background(
                    RoundedRectangle(cornerRadius: 28)
                        .fill(Color(red: 0.05, green: 0.14, blue: 0.28).opacity(0.90))
                        .shadow(color: .black.opacity(0.3), radius: 20)
                )
                .padding(.horizontal, 18)
                .scaleEffect(shown ? 1 : 0.88).opacity(shown ? 1 : 0)
                
                Spacer()
                
                VStack(spacing: 12) {
                    Button {
                        SoundManager.shared.playTap()
                        showLearnCard = false
                        showScanView  = true
                    } label: {
                        HStack(spacing: 10) {
                            Image(systemName: "camera.viewfinder").font(.system(size: 16, weight: .bold))
                            Text("Scan Now")
                                .font(.system(size: 17, weight: .bold, design: .rounded))
                        }
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity).frame(height: 54)
                        .background(LinearGradient(
                            colors: [OceanTheme.teal, OceanTheme.seaGreen],
                            startPoint: .leading, endPoint: .trailing))
                        .cornerRadius(16)
                        .shadow(color: OceanTheme.teal.opacity(0.45), radius: 12, x: 0, y: 5)
                    }
                    .accessibilityLabel("Open scanner")
                    
                    Button {
                        nextTip()
                    } label: {
                        HStack(spacing: 6) {
                            Text("Next Tip")
                            Image(systemName: "arrow.right.circle.fill")
                        }
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundColor(.white.opacity(0.55))
                    }
                    .accessibilityLabel("Show next recycling tip")
                }
                .padding(.horizontal, 22).padding(.bottom, 52)
            }
        }
        .onAppear {
            tipIndex = Int.random(in: 0..<tips.count)
            withAnimation(.spring(response: 0.55, dampingFraction: 0.72).delay(0.1)) { shown = true }
        }
    }
    
    private func nextTip() {
        SoundManager.shared.hapticLight()
        iconBounce = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) { iconBounce = false }
        withAnimation(.easeOut(duration: 0.18)) { contentOpacity = 0; cardOffset = -24 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.22) {
            tipIndex = (tipIndex + 1) % tips.count
            cardOffset = 24
            withAnimation(.easeIn(duration: 0.22)) { contentOpacity = 1; cardOffset = 0 }
        }
    }
}

struct RecycleTipsCarousel: View {
    let highlightType: TrashType
    
    private struct Tip {
        let icon: String; let color: Color
        let title: String; let detail: String; let emoji: String
    }
    
    private var tips: [Tip] {[
        Tip(icon: "1.circle.fill",
            color: Color(red: 0.20, green: 0.65, blue: 1.0),
            title: "Check the symbol",
            detail: "The recycling number inside the triangle tells you the plastic type. #1 (PET) and #2 (HDPE) are accepted almost everywhere.",
            emoji: "♻️"),
        Tip(icon: "drop.fill",
            color: OceanTheme.teal,
            title: "Rinse before recycling",
            detail: "Food residue contaminates entire batches. A quick cold rinse is enough — you don't need soap.",
            emoji: "💧"),
        Tip(icon: "archivebox.fill",
            color: OceanTheme.seaGreen,
            title: "Remove the label",
            detail: "Paper labels slow sorting machines. Peel them off when possible. Plastic labels are usually fine to leave on.",
            emoji: "🏷️"),
        Tip(icon: "bag.fill",
            color: Color(red: 0.55, green: 0.35, blue: 0.90),
            title: "Soft plastics separately",
            detail: "Cling film, carrier bags, and bubble wrap jam sorting machines. Take them to supermarket soft-plastic drop-off points.",
            emoji: "🛍️"),
        Tip(icon: "xmark.circle.fill",
            color: OceanTheme.coral,
            title: "Never wish-cycle",
            detail: "If you're unsure whether something is recyclable, don't guess. Contamination ruins entire loads at sorting facilities.",
            emoji: "🚫"),
        Tip(icon: "bolt.fill",
            color: OceanTheme.gold,
            title: highlightType.label + " — \(highlightType.recycleCode)",
            detail: highlightType.fact,
            emoji: "💡"),
    ]}
    
    @State private var current      = 0
    @State private var shown        = false
    @State private var iconBounce   = false
    @State private var cardOffset: CGFloat = 0
    @State private var cardOpacity  = 1.0
    
    var body: some View {
        VStack(spacing: 0) {
            // Header
            HStack {
                Image(systemName: "lightbulb.fill")
                    .font(.system(size: 11)).foregroundColor(OceanTheme.gold)
                Text("RECYCLE SMARTER")
                    .font(.system(size: 10, weight: .heavy)).foregroundColor(.white.opacity(0.5)).tracking(1)
                Spacer()
                // Page dots
                HStack(spacing: 5) {
                    ForEach(0..<tips.count, id: \.self) { i in
                        Circle()
                            .fill(i == current ? tips[current].color : Color.white.opacity(0.2))
                            .frame(width: i == current ? 7 : 4, height: i == current ? 7 : 4)
                            .animation(.spring(response: 0.3), value: current)
                    }
                }
            }
            .padding(.horizontal, 14).padding(.top, 12).padding(.bottom, 8)
            
            // Card
            HStack(spacing: 12) {
                ZStack {
                    Circle()
                        .fill(tips[current].color.opacity(0.15))
                        .frame(width: 46, height: 46)
                    Text(tips[current].emoji)
                        .font(.system(size: 22))
                        .scaleEffect(iconBounce ? 1.18 : 1.0)
                        .animation(.spring(response: 0.28, dampingFraction: 0.4), value: iconBounce)
                }
                
                VStack(alignment: .leading, spacing: 4) {
                    Text(tips[current].title)
                        .font(.system(size: 13, weight: .bold))
                        .foregroundColor(tips[current].color)
                        .lineLimit(1)
                    Text(tips[current].detail)
                        .font(.system(size: 11, weight: .medium))
                        .foregroundColor(.white.opacity(0.68))
                        .fixedSize(horizontal: false, vertical: true)
                        .lineSpacing(2)
                }
                .opacity(cardOpacity)
                .offset(x: cardOffset)
                
                Spacer(minLength: 0)
            }
            .padding(.horizontal, 14).padding(.bottom, 12)
            
            // Swipe / tap hint + next button
            HStack {
                Text("Swipe for more tips")
                    .font(.system(size: 9)).foregroundColor(.white.opacity(0.28))
                Spacer()
                Button {
                    SoundManager.shared.hapticLight()
                    nextTip()
                } label: {
                    HStack(spacing: 4) {
                        Text("Next")
                            .font(.system(size: 11, weight: .semibold))
                        Image(systemName: "chevron.right")
                            .font(.system(size: 9, weight: .bold))
                    }
                    .foregroundColor(tips[current].color)
                }
            }
            .padding(.horizontal, 14).padding(.bottom, 10)
        }
        .background(Color.white.opacity(0.07))
        .cornerRadius(16)
        .overlay(RoundedRectangle(cornerRadius: 16)
            .stroke(tips[current].color.opacity(0.22), lineWidth: 1)
            .animation(.easeInOut(duration: 0.4), value: current))
        .opacity(shown ? 1 : 0).offset(y: shown ? 0 : 18)
        .gesture(
            DragGesture(minimumDistance: 30)
                .onEnded { v in
                    if v.translation.width < -20 { nextTip() }
                    else if v.translation.width > 20 { prevTip() }
                }
        )
        .onAppear {
            // Start on the tip specific to the scanned item
            current = tips.count - 1
            withAnimation(.spring(response: 0.5, dampingFraction: 0.78).delay(0.3)) { shown = true }
        }
        .accessibilityLabel("Recycling tip: \(tips[current].title). \(tips[current].detail)")
    }
    
    private func nextTip() {
        animateTransition(direction: -1) { current = (current + 1) % tips.count }
    }
    private func prevTip() {
        animateTransition(direction: 1) { current = (current - 1 + tips.count) % tips.count }
    }
    private func animateTransition(direction: CGFloat, change: @escaping () -> Void) {
        iconBounce = true
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) { iconBounce = false }
        withAnimation(.easeOut(duration: 0.15)) { cardOpacity = 0; cardOffset = direction * 20 }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
            change()
            cardOffset = -direction * 20
            withAnimation(.easeIn(duration: 0.18)) { cardOpacity = 1; cardOffset = 0 }
        }
    }
}
