import AVFoundation
import SwiftUI

final class SoundManager: ObservableObject {
    
    static let shared = SoundManager()
    
    private var ambientPlayer:     AVAudioPlayer?
    private var wavePlayer:        AVAudioPlayer?
    private var rumblePlayer:      AVAudioPlayer?
    private var brightPlayer:      AVAudioPlayer?
    private var tapPlayer:         AVAudioPlayer?
    private var successPlayer:     AVAudioPlayer?
    private var missPlayer:        AVAudioPlayer?
    private var achievementPlayer: AVAudioPlayer?
    private var bubblePlayer:      AVAudioPlayer?
    
    private var lastHealthState = HealthAudioState.normal
    private var isAppActive     = true
    private(set) var isAmbientPlaying = false
    
    private enum HealthAudioState { case low, normal, high }
    
    private init() {
        configureAudioSession()
        preloadPlayers()
    }
    
    private func configureAudioSession() {
#if os(iOS)
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.ambient, mode: .default, options: [.mixWithOthers])
        try? session.setActive(true)
#endif
    }
    
    private func preloadPlayers() {
        ambientPlayer    = makePlayer(named: "ocean_ambient",  ext: "mp3", volume: 0.0,  loops: true)
        wavePlayer       = makePlayer(named: "waves",          ext: "mp3", volume: 0.22, loops: true)
        rumblePlayer     = makePlayer(named: "ocean_rumble",   ext: "mp3", volume: 0.0,  loops: true)
        brightPlayer     = makePlayer(named: "bright_ambient", ext: "mp3", volume: 0.0,  loops: true)
        tapPlayer        = makePlayer(named: "tap_soft",       ext: "mp3", volume: 0.45, loops: false)
        successPlayer    = makePlayer(named: "catch_success",  ext: "mp3", volume: 0.65, loops: false)
        missPlayer       = makePlayer(named: "miss_splash",    ext: "mp3", volume: 0.55, loops: false)
        achievementPlayer = makePlayer(named: "achievement",   ext: "mp3", volume: 0.72, loops: false)
        bubblePlayer     = makePlayer(named: "bubble_pop",     ext: "mp3", volume: 0.35, loops: false)
    }
    
    private func makePlayer(named name: String, ext: String, volume: Float, loops: Bool) -> AVAudioPlayer? {
        guard let url = Bundle.main.url(forResource: name, withExtension: ext) else { return nil }
        let player = try? AVAudioPlayer(contentsOf: url)
        player?.volume = volume
        player?.numberOfLoops = loops ? -1 : 0
        player?.prepareToPlay()
        return player
    }
    
    // ── Ambient Lifecycle ─────────────────────────────────────────
    func startAmbient() {
        guard !isAmbientPlaying else { return }
        isAmbientPlaying = true
        ambientPlayer?.volume = 0
        ambientPlayer?.play()
        wavePlayer?.play()
        fadeIn(player: ambientPlayer, to: 0.30, duration: EcoConfiguration.audioFadeInDuration)
        fadeIn(player: wavePlayer,    to: 0.22, duration: EcoConfiguration.audioFadeInDuration)
    }
    
    func fadeOutAmbient() {
        guard isAmbientPlaying else { return }
        isAmbientPlaying = false
        fadeOut(player: ambientPlayer, duration: EcoConfiguration.audioFadeOutDuration)
        fadeOut(player: wavePlayer,    duration: EcoConfiguration.audioFadeOutDuration)
        fadeOut(player: rumblePlayer,  duration: EcoConfiguration.audioFadeOutDuration)
        fadeOut(player: brightPlayer,  duration: EcoConfiguration.audioFadeOutDuration)
    }
    
    func handleAppBackground() {
        isAppActive = false
        fadeOutAmbient()
    }
    
    func handleAppForeground() {
        guard !isAppActive else { return }
        isAppActive = true
        startAmbient()
    }
    
    // ── Health-Reactive Ambient ───────────────────────────────────
    func updateAmbientForHealth(_ health: Double) {
        let newState: HealthAudioState
        if health < EcoConfiguration.audioLowHealthThreshold {
            newState = .low
        } else if health > EcoConfiguration.audioHighHealthThreshold {
            newState = .high
        } else {
            newState = .normal
        }
        guard newState != lastHealthState else { return }
        lastHealthState = newState
        switch newState {
        case .low:
            fadeIn(player: rumblePlayer, to: 0.18, duration: 2.0)
            fadeOut(player: brightPlayer, duration: 1.5)
        case .normal:
            fadeOut(player: rumblePlayer, duration: 2.0)
            fadeOut(player: brightPlayer, duration: 1.5)
        case .high:
            fadeOut(player: rumblePlayer, duration: 1.5)
            fadeIn(player: brightPlayer, to: 0.16, duration: 2.0)
        }
    }
    
    // ── One-Shot SFX ──────────────────────────────────────────────
    func playTap()         { playSFX(tapPlayer)         }
    func playSuccess()     { playSFX(successPlayer);  hapticSuccess() }
    func playMiss()        { playSFX(missPlayer);     hapticError()   }
    func playAchievement() { playSFX(achievementPlayer); hapticHeavy() }
    func playBubble()      { playSFX(bubblePlayer)       }
    
    private func playSFX(_ player: AVAudioPlayer?) {
        guard let player else { return }
        if player.isPlaying { player.stop(); player.currentTime = 0 }
        player.play()
    }
    
    // ── Haptic ────────────────────────────────────────────────────
    func hapticLight() {
#if os(iOS)
        UIImpactFeedbackGenerator(style: .light).impactOccurred()
#endif
    }
    private func hapticSuccess() {
#if os(iOS)
        UIImpactFeedbackGenerator(style: .medium).impactOccurred()
#endif
    }
    private func hapticError() {
#if os(iOS)
        UINotificationFeedbackGenerator().notificationOccurred(.error)
#endif
    }
    private func hapticHeavy() {
#if os(iOS)
        UIImpactFeedbackGenerator(style: .heavy).impactOccurred()
#endif
    }
    
    // ── Fade Utilities ────────────────────────────────────────────
    private func fadeIn(player: AVAudioPlayer?, to targetVolume: Float, duration: Double) {
        guard let player else { return }
        if !player.isPlaying { player.volume = 0; player.play() }
        animateVolume(player: player, to: targetVolume, duration: duration)
    }
    
    private func fadeOut(player: AVAudioPlayer?, duration: Double) {
        guard let player, player.isPlaying else { return }
        animateVolume(player: player, to: 0, duration: duration) { player.stop(); player.currentTime = 0 }
    }
    
    private func animateVolume(player: AVAudioPlayer, to target: Float, duration: Double, completion: (() -> Void)? = nil) {
        let steps    = 30
        let interval = duration / Double(steps)
        let start    = player.volume
        let delta    = (target - start) / Float(steps)
        for step in 0...steps {
            DispatchQueue.main.asyncAfter(deadline: .now() + Double(step) * interval) {
                player.volume = max(0, min(1, start + delta * Float(step)))
                if step == steps { completion?() }
            }
        }
    }
}
